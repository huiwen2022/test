import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import os
import sys
# 取得 libs 資料夾的絕對路徑並加到 sys.path
sys.path.append(os.path.join(os.path.dirname(__file__), "libs"))
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment
from openpyxl.utils import get_column_letter
import os

class ProductsTab:
    def __init__(self, parent, main_app):
        self.parent = parent
        self.main_app = main_app
        self.data = []
        self.columns = ["產品編號", "產品名稱", "分類", "價格", "庫存", "供應商", "備註"]
        
        # 必填欄位定義
        self.required_fields = ["產品編號", "產品名稱", "分類", "價格"]
        
        # 下拉選單選項定義
        self.dropdown_options = {
            "分類": ["電子產品", "家具", "文具", "服裝", "食品", "其他"]
        }
        
        # 創建主框架
        self.frame = ttk.Frame(parent)
        self.setup_ui()
    
    def setup_ui(self):
        """設置用戶介面"""
        # 使用PanedWindow分割上下兩部分
        self.paned_window = ttk.PanedWindow(self.frame, orient=tk.VERTICAL)
        self.paned_window.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # 上半部分：資料顯示區域
        self.setup_data_display()
        
        # 下半部分：編輯區域
        self.setup_edit_area()
        
        # 設置分割比例 - 延遲執行確保視窗已完全載入
        self.frame.after(200, self.set_paned_position)
    
    def setup_data_display(self):
        """設置資料顯示區域（上半部分）"""
        # 上半部分框架
        self.top_frame = ttk.Frame(self.paned_window)
        self.paned_window.add(self.top_frame, weight=3)
        
        # 工具欄
        toolbar = ttk.Frame(self.top_frame)
        toolbar.pack(fill=tk.X, padx=5, pady=5)
        
        ttk.Button(toolbar, text="刪除選中", command=self.delete_row).pack(side=tk.LEFT, padx=2)
        ttk.Button(toolbar, text="複製選中", command=self.copy_row).pack(side=tk.LEFT, padx=2)
        ttk.Button(toolbar, text="清除全部", command=self.clear_all_data).pack(side=tk.LEFT, padx=2)
        ttk.Separator(toolbar, orient="vertical").pack(side=tk.LEFT, padx=10, fill=tk.Y)
        ttk.Button(toolbar, text="匯出Excel", command=self.export_to_excel).pack(side=tk.LEFT, padx=2)
        
        # 創建Treeview框架
        self.tree_frame = ttk.Frame(self.top_frame)
        self.tree_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # 創建Treeview和滾動條
        self.tree = ttk.Treeview(self.tree_frame, columns=self.columns, show="headings")
        
        # 設置列標題
        for col in self.columns:
            self.tree.heading(col, text=col)
            self.tree.column(col, width=100, anchor="center")
        
        # 滾動條
        v_scrollbar = ttk.Scrollbar(self.tree_frame, orient="vertical", command=self.tree.yview)
        h_scrollbar = ttk.Scrollbar(self.tree_frame, orient="horizontal", command=self.tree.xview)
        self.tree.configure(yscrollcommand=v_scrollbar.set, xscrollcommand=h_scrollbar.set)
        
        # 佈局
        self.tree.grid(row=0, column=0, sticky="nsew")
        v_scrollbar.grid(row=0, column=1, sticky="ns")
        h_scrollbar.grid(row=1, column=0, sticky="ew")
        
        self.tree_frame.grid_rowconfigure(0, weight=1)
        self.tree_frame.grid_columnconfigure(0, weight=1)
        
        # 選中事件
        self.tree.bind("<<TreeviewSelect>>", self.on_select)
    
    def setup_edit_area(self):
        """設置編輯區域（下半部分）"""
        # 下半部分框架
        self.bottom_frame = ttk.Frame(self.paned_window)
        self.paned_window.add(self.bottom_frame, weight=1)
        
        # 標題
        ttk.Label(self.bottom_frame, text="資料編輯區", font=("Arial", 12, "bold")).pack(pady=5)
        
        # 創建可滾動的編輯區域
        self.canvas = tk.Canvas(self.bottom_frame)
        self.scrollbar = ttk.Scrollbar(self.bottom_frame, orient="vertical", command=self.canvas.yview)
        self.scrollable_frame = ttk.Frame(self.canvas)
        
        self.scrollable_frame.bind(
            "<Configure>",
            lambda e: self.canvas.configure(scrollregion=self.canvas.bbox("all"))
        )
        
        self.canvas.create_window((0, 0), window=self.scrollable_frame, anchor="nw")
        self.canvas.configure(yscrollcommand=self.scrollbar.set)
        
        # 編輯表單框架（放在可滾動框架內）
        self.edit_frame = ttk.Frame(self.scrollable_frame)
        self.edit_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)
        
        # 創建輸入欄位
        self.entries = {}
        self.create_input_fields()
        
        # 按鈕框架（放在可滾動框架內）
        button_frame = ttk.Frame(self.scrollable_frame)
        button_frame.pack(pady=10)
        
        ttk.Button(button_frame, text="新增資料", command=self.add_row).pack(side=tk.LEFT, padx=5)
        ttk.Button(button_frame, text="修改資料", command=self.update_row).pack(side=tk.LEFT, padx=5)
        ttk.Button(button_frame, text="清空表單", command=self.clear_form).pack(side=tk.LEFT, padx=5)
        
        # 佈局滾動區域
        self.canvas.pack(side="left", fill="both", expand=True)
        self.scrollbar.pack(side="right", fill="y")
        
        # 綁定滑鼠滾輪事件
        def _on_mousewheel(event):
            self.canvas.yview_scroll(int(-1*(event.delta/120)), "units")
        self.canvas.bind("<MouseWheel>", _on_mousewheel)
        
        # 目前編輯的項目ID
        self.current_editing_item = None
    
    def create_input_fields(self):
        """創建輸入欄位"""
        for i, col in enumerate(self.columns):
            row = i // 2
            column = (i % 2) * 2
            
            # 標籤
            label_text = col
            if col in self.required_fields:
                label_text += " *"
            
            label = ttk.Label(self.edit_frame, text=f"{label_text}:")
            label.grid(row=row, column=column, padx=5, pady=3, sticky="w")
            
            # 輸入欄位
            if col in self.dropdown_options:
                # 下拉選單
                entry = ttk.Combobox(self.edit_frame, values=self.dropdown_options[col], state="readonly", width=25)
            elif col == "備註":
                # 多行文字框
                entry = tk.Text(self.edit_frame, width=30, height=3)
            else:
                # 一般輸入框
                entry = ttk.Entry(self.edit_frame, width=30)
            
            entry.grid(row=row, column=column+1, padx=5, pady=3, sticky="w")
            self.entries[col] = entry
        
        # 必填提示
        required_label = ttk.Label(self.edit_frame, text="* 為必填欄位", foreground="red", font=("Arial", 8))
        required_label.grid(row=len(self.columns)//2 + 1, column=0, columnspan=4, pady=5)
    
    def on_select(self, event):
        """當選中項目時，載入資料到編輯區"""
        selected = self.tree.selection()
        if selected:
            item = self.tree.item(selected[0])
            values = item['values']
            self.load_data_to_form(values)
            self.current_editing_item = selected[0]
    
    def load_data_to_form(self, values):
        """載入資料到表單"""
        for i, col in enumerate(self.columns):
            entry = self.entries[col]
            
            if isinstance(entry, tk.Text):
                entry.delete("1.0", tk.END)
                entry.insert("1.0", str(values[i]))
            else:
                if hasattr(entry, 'set'):  # Combobox
                    entry.set(str(values[i]))
                else:  # Entry
                    entry.delete(0, tk.END)
                    entry.insert(0, str(values[i]))
    
    def get_form_data(self):
        """從表單獲取資料"""
        data = []
        for col in self.columns:
            entry = self.entries[col]
            
            if isinstance(entry, tk.Text):
                value = entry.get("1.0", "end-1c").strip()
            else:
                value = entry.get().strip()
            
            data.append(value)
        return data
    
    def validate_form_data(self, data):
        """驗證表單資料"""
        for i, col in enumerate(self.columns):
            # 必填欄位檢查
            if col in self.required_fields and not data[i]:
                messagebox.showerror("錯誤", f"{col} 為必填欄位")
                return False
            
            # 數字欄位檢查
            if col in ["價格", "庫存"] and data[i]:
                try:
                    float(data[i])
                except ValueError:
                    messagebox.showerror("錯誤", f"{col} 必須是數字")
                    return False
        
        return True
    
    def clear_form(self):
        """清空表單"""
        for col in self.columns:
            entry = self.entries[col]
            
            if isinstance(entry, tk.Text):
                entry.delete("1.0", tk.END)
            else:
                if hasattr(entry, 'set'):  # Combobox
                    entry.set("")
                else:  # Entry
                    entry.delete(0, tk.END)
        
        self.current_editing_item = None
    
    def add_row(self):
        """新增資料"""
        data = self.get_form_data()
        
        if not self.validate_form_data(data):
            return
        
        # 檢查產品編號是否重複
        for existing_data in self.data:
            if existing_data[0] == data[0]:
                messagebox.showerror("錯誤", "產品編號已存在")
                return
        
        # 新增到資料和樹狀檢視
        self.data.append(data)
        self.tree.insert("", "end", values=data)
        
        # 清空表單
        self.clear_form()
        
        # 儲存資料
        self.main_app.save_data()
        
        messagebox.showinfo("成功", "資料已新增")
    
    def update_row(self):
        """修改資料"""
        if not self.current_editing_item:
            messagebox.showwarning("警告", "請先選擇要修改的項目")
            return
        
        data = self.get_form_data()
        
        if not self.validate_form_data(data):
            return
        
        # 獲取原始資料
        old_values = self.tree.item(self.current_editing_item)['values']
        
        # 如果產品編號改變，檢查是否重複
        if data[0] != old_values[0]:
            for existing_data in self.data:
                if existing_data[0] == data[0]:
                    messagebox.showerror("錯誤", "產品編號已存在")
                    return
        
        # 更新資料
        if list(old_values) in self.data:
            index = self.data.index(list(old_values))
            self.data[index] = data
        
        # 更新樹狀檢視
        self.tree.item(self.current_editing_item, values=data)
        
        # 清空表單
        self.clear_form()
        
        # 儲存資料
        self.main_app.save_data()
        
        messagebox.showinfo("成功", "資料已修改")
    
    def delete_row(self):
        """刪除選中的資料"""
        selected = self.tree.selection()
        if not selected:
            messagebox.showwarning("警告", "請先選擇要刪除的項目")
            return
        
        if messagebox.askyesno("確認", "確定要刪除選中的項目嗎？"):
            for item in selected:
                # 從data中移除
                values = self.tree.item(item)['values']
                if list(values) in self.data:
                    self.data.remove(list(values))
                # 從tree中移除
                self.tree.delete(item)
            
            # 清空表單
            self.clear_form()
            
            # 儲存資料
            self.main_app.save_data()
    
    def copy_row(self):
        """複製選中的資料"""
        selected = self.tree.selection()
        if not selected:
            messagebox.showwarning("警告", "請先選擇要複製的項目")
            return
        
        item = self.tree.item(selected[0])
        values = list(item['values'])
        
        # 修改編號避免重複
        original_id = values[0]
        counter = 1
        while True:
            new_id = f"{original_id}_copy{counter}"
            # 檢查是否重複
            exists = False
            for existing_data in self.data:
                if existing_data[0] == new_id:
                    exists = True
                    break
            if not exists:
                values[0] = new_id
                break
            counter += 1
        
        # 新增資料
        self.data.append(values)
        self.tree.insert("", "end", values=values)
        
        # 儲存資料
        self.main_app.save_data()
    
    def clear_all_data(self):
        """清除所有資料"""
        if messagebox.askyesno("確認", "確定要清除所有產品資料嗎？"):
            self.data.clear()
            for item in self.tree.get_children():
                self.tree.delete(item)
            self.clear_form()
            self.main_app.save_data()
    
    def load_sample_data(self):
        """載入範例資料"""
        if not self.data:  # 只有在沒有資料時才載入範例
            sample_data = [
                ["P001", "筆記型電腦", "電子產品", "25000", "50", "ABC公司", "高效能筆電"],
                ["P002", "無線滑鼠", "電子產品", "800", "200", "XYZ公司", "藍牙連接"],
                ["P003", "辦公椅", "家具", "3500", "30", "家具行", "人體工學設計"],
            ]
            self.load_data_from_list(sample_data)
    
    def load_data_from_list(self, data_list):
        """從清單載入資料"""
        # 清空現有資料
        self.data.clear()
        for item in self.tree.get_children():
            self.tree.delete(item)
        
        # 載入新資料
        for item in data_list:
            self.data.append(item)
            self.tree.insert("", "end", values=item)
    
    def export_to_excel(self):
        """匯出到Excel"""
        if not self.data:
            messagebox.showwarning("警告", "沒有資料可以匯出")
            return
        
        try:
            # 創建工作簿
            wb = Workbook()
            ws = wb.active
            ws.title = "產品管理"
            
            # 設置標題行
            for col_num, column_title in enumerate(self.columns, 1):
                cell = ws.cell(row=1, column=col_num)
                cell.value = column_title
                # 標題樣式：藍色背景，白色字體，粗體
                cell.fill = PatternFill(start_color="366092", end_color="366092", fill_type="solid")
                cell.font = Font(color="FFFFFF", bold=True)
                cell.alignment = Alignment(horizontal="center", vertical="center")
            
            # 填入資料
            for row_num, row_data in enumerate(self.data, 2):
                for col_num, cell_value in enumerate(row_data, 1):
                    cell = ws.cell(row=row_num, column=col_num)
                    cell.value = cell_value
                    
                    # 第7欄（備註）設為黃色背景
                    if col_num == 7:
                        cell.fill = PatternFill(start_color="FFFF00", end_color="FFFF00", fill_type="solid")
                    
                    cell.alignment = Alignment(horizontal="center", vertical="center")
            
            # 凍結第一列和第一欄
            ws.freeze_panes = "B2"
            
            # 調整欄寬
            for column in ws.columns:
                max_length = 0
                column_letter = get_column_letter(column[0].column)
                for cell in column:
                    try:
                        if len(str(cell.value)) > max_length:
                            max_length = len(str(cell.value))
                    except:
                        pass
                adjusted_width = min(max_length + 2, 50)
                ws.column_dimensions[column_letter].width = adjusted_width
            
            # 選擇儲存位置
            filename = filedialog.asksaveasfilename(
                defaultextension=".xlsx",
                filetypes=[("Excel files", "*.xlsx"), ("All files", "*.*")],
                title="儲存產品管理Excel檔案"
            )
            
            if filename:
                wb.save(filename)
                messagebox.showinfo("成功", f"已成功匯出到：{filename}")
        
        except Exception as e:
            messagebox.showerror("錯誤", f"匯出Excel時發生錯誤：{str(e)}")
    
    def set_paned_position(self):
        """設置分割視窗位置"""
        try:
            # 設置上半部分占約55%的高度，給編輯區域更多空間
            total_height = self.paned_window.winfo_height()
            if total_height > 100:  # 確保視窗已經正確載入
                self.paned_window.sashpos(0, int(total_height * 0.55))
            else:
                # 如果高度還沒確定，再次延遲執行
                self.frame.after(200, self.set_paned_position)
        except:
            # 如果設置失敗，使用固定值
            self.paned_window.sashpos(0, 300)