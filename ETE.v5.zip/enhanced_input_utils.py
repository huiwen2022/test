"""
Enhanced Input Utils - 改善的輸入控件工具類別
提供帶提示文字的輸入框和智能日期輸入功能
"""

import tkinter as tk
from tkinter import ttk
import datetime
import re

class PlaceholderEntry(tk.Entry):
    """帶有提示文字的Entry控件"""
    
    def __init__(self, master=None, placeholder="", placeholder_color="gray", **kw):
        super().__init__(master, **kw)
        
        self.placeholder = placeholder
        self.placeholder_color = placeholder_color
        self.default_fg_color = self['fg'] or 'black'
        
        self.bind("<FocusIn>", self.focus_in)
        self.bind("<FocusOut>", self.focus_out)
        
        self.put_placeholder()

    def put_placeholder(self):
        """顯示提示文字"""
        if not self.get():
            self.insert(0, self.placeholder)
            self['fg'] = self.placeholder_color

    def focus_in(self, *args):
        """獲得焦點時清除提示文字"""
        if self.get() == self.placeholder:
            self.delete('0', 'end')
            self['fg'] = self.default_fg_color

    def focus_out(self, *args):
        """失去焦點時恢復提示文字"""
        self.put_placeholder()
    
    def get_value(self):
        """獲取實際值（排除placeholder）"""
        value = self.get()
        return '' if value == self.placeholder else value
    
    def set_value(self, value):
        """設置值"""
        self.delete(0, tk.END)
        if value:
            self.insert(0, str(value))
            self['fg'] = self.default_fg_color
        else:
            self.put_placeholder()

class DateEntry(tk.Frame):
    """下拉式日期選擇控件"""
    
    def __init__(self, master=None, **kw):
        super().__init__(master, **kw)
        
        # 年份
        self.year_var = tk.StringVar()
        self.year_combo = ttk.Combobox(self, textvariable=self.year_var, width=6, state="readonly")
        current_year = datetime.datetime.now().year
        years = [str(y) for y in range(current_year-10, current_year+11)]
        self.year_combo['values'] = years
        self.year_combo.set(str(current_year))
        self.year_combo.pack(side=tk.LEFT, padx=2)
        
        tk.Label(self, text="年").pack(side=tk.LEFT)
        
        # 月份
        self.month_var = tk.StringVar()
        self.month_combo = ttk.Combobox(self, textvariable=self.month_var, width=4, state="readonly")
        months = [f"{i:02d}" for i in range(1, 13)]
        self.month_combo['values'] = months
        self.month_combo.set(f"{datetime.datetime.now().month:02d}")
        self.month_combo.pack(side=tk.LEFT, padx=2)
        
        tk.Label(self, text="月").pack(side=tk.LEFT)
        
        # 日期
        self.day_var = tk.StringVar()
        self.day_combo = ttk.Combobox(self, textvariable=self.day_var, width=4, state="readonly")
        self.update_days()
        self.day_combo.set(f"{datetime.datetime.now().day:02d}")
        self.day_combo.pack(side=tk.LEFT, padx=2)
        
        tk.Label(self, text="日").pack(side=tk.LEFT)
        
        # 今天按鈕
        self.today_btn = tk.Button(self, text="今天", command=self.set_today, 
                                  font=("Arial", 8), relief=tk.RAISED, bd=1)
        self.today_btn.pack(side=tk.LEFT, padx=5)
        
        # 綁定事件
        self.year_combo.bind("<<ComboboxSelected>>", self.update_days)
        self.month_combo.bind("<<ComboboxSelected>>", self.update_days)
    
    def update_days(self, event=None):
        """更新日期選項"""
        try:
            year = int(self.year_var.get())
            month = int(self.month_var.get())
            
            # 計算該月的天數
            if month == 12:
                days_in_month = (datetime.date(year+1, 1, 1) - datetime.date(year, month, 1)).days
            else:
                days_in_month = (datetime.date(year, month+1, 1) - datetime.date(year, month, 1)).days
            
            days = [f"{i:02d}" for i in range(1, days_in_month + 1)]
            self.day_combo['values'] = days
            
            # 如果當前選擇的日期超過該月天數，調整為該月最後一天
            current_day = self.day_var.get()
            if current_day and int(current_day) > days_in_month:
                self.day_var.set(f"{days_in_month:02d}")
                
        except ValueError:
            pass
    
    def set_today(self):
        """設置為今天的日期"""
        today = datetime.datetime.now()
        self.year_var.set(str(today.year))
        self.month_var.set(f"{today.month:02d}")
        self.day_var.set(f"{today.day:02d}")
        self.update_days()
    
    def get_date(self):
        """獲取日期字符串 (YYYY-MM-DD 格式)"""
        try:
            year = self.year_var.get()
            month = self.month_var.get()
            day = self.day_var.get()
            if year and month and day:
                return f"{year}-{month}-{day}"
            return ""
        except:
            return ""
    
    def set_date(self, date_str):
        """設置日期 (接受 YYYY-MM-DD 格式)"""
        try:
            if not date_str:
                self.set_today()
                return
            
            if isinstance(date_str, str):
                date_str = date_str.strip()
                
                # YYYY-MM-DD 格式
                if re.match(r'^\d{4}-\d{1,2}-\d{1,2}$', date_str):
                    parts = date_str.split('-')
                    year, month, day = parts[0], int(parts[1]), int(parts[2])
                # YYYY/MM/DD 格式
                elif re.match(r'^\d{4}/\d{1,2}/\d{1,2}$', date_str):
                    parts = date_str.split('/')
                    year, month, day = parts[0], int(parts[1]), int(parts[2])
                else:
                    return
                
                self.year_var.set(str(year))
                self.month_var.set(f"{month:02d}")
                self.day_var.set(f"{day:02d}")
                self.update_days()
                
        except:
            self.set_today()

class SmartDateEntry(tk.Frame):
    """智能日期輸入控件 - 支援多種輸入格式"""
    
    def __init__(self, master=None, **kw):
        super().__init__(master, **kw)
        
        self.entry = PlaceholderEntry(
            self, 
            placeholder="YYYY-MM-DD 或 今天/昨天",
            placeholder_color="gray",
            width=18
        )
        self.entry.pack(side=tk.LEFT, padx=2)
        
        self.entry.bind("<KeyRelease>", self.on_text_change)
        self.entry.bind("<FocusOut>", self.format_date)
        
        # 快速按鈕
        btn_frame = tk.Frame(self)
        btn_frame.pack(side=tk.LEFT, padx=5)
        
        tk.Button(btn_frame, text="今天", command=self.set_today, 
                 font=("Arial", 8), width=4, relief=tk.RAISED, bd=1).pack(side=tk.LEFT, padx=1)
        tk.Button(btn_frame, text="昨天", command=self.set_yesterday, 
                 font=("Arial", 8), width=4, relief=tk.RAISED, bd=1).pack(side=tk.LEFT, padx=1)
        tk.Button(btn_frame, text="清空", command=self.clear_date, 
                 font=("Arial", 8), width=4, relief=tk.RAISED, bd=1).pack(side=tk.LEFT, padx=1)
    
    def on_text_change(self, event=None):
        """文字變更時的處理"""
        text = self.entry.get().lower().strip()
        
        # 快速輸入處理
        if text in ['今天', 'today', '0']:
            self.set_today()
        elif text in ['昨天', 'yesterday', '-1']:
            self.set_yesterday()
    
    def format_date(self, event=None):
        """格式化日期"""
        text = self.entry.get_value().strip()
        if not text:
            return
        
        try:
            formatted_date = self.parse_date_input(text)
            if formatted_date:
                self.entry.delete(0, tk.END)
                self.entry.insert(0, formatted_date)
                self.entry['fg'] = self.entry.default_fg_color
        except:
            pass
    
    def parse_date_input(self, text):
        """解析各種日期輸入格式"""
        text = text.lower().strip()
        
        if not text:
            return ""
        
        today = datetime.datetime.now()
        
        # 中文快速輸入
        if text in ['今天', 'today']:
            return today.strftime('%Y-%m-%d')
        elif text in ['昨天', 'yesterday']:
            yesterday = today - datetime.timedelta(days=1)
            return yesterday.strftime('%Y-%m-%d')
        elif text in ['明天', 'tomorrow']:
            tomorrow = today + datetime.timedelta(days=1)
            return tomorrow.strftime('%Y-%m-%d')
        
        # 數字快速輸入 (相對天數)
        if re.match(r'^-?\d+$', text):
            days_offset = int(text)
            target_date = today + datetime.timedelta(days=days_offset)
            return target_date.strftime('%Y-%m-%d')
        
        # 標準日期格式
        date_patterns = [
            (r'^(\d{4})-(\d{1,2})-(\d{1,2})$', '%Y-%m-%d'),
            (r'^(\d{4})/(\d{1,2})/(\d{1,2})$', '%Y/%m/%d'),
            (r'^(\d{1,2})-(\d{1,2})-(\d{4})$', '%d-%m-%Y'),
            (r'^(\d{1,2})/(\d{1,2})/(\d{4})$', '%d/%m/%Y'),
            (r'^(\d{4})(\d{2})(\d{2})$', '%Y%m%d'),
        ]
        
        for pattern, fmt in date_patterns:
            if re.match(pattern, text):
                try:
                    if fmt in ['%d-%m-%Y', '%d/%m/%Y']:
                        # 日月年格式需要重新排列
                        match = re.match(pattern, text)
                        if fmt == '%d-%m-%Y':
                            reformatted = f"{match.group(3)}-{match.group(2):0>2}-{match.group(1):0>2}"
                        else:  # %d/%m/%Y
                            reformatted = f"{match.group(3)}-{match.group(2):0>2}-{match.group(1):0>2}"
                        date_obj = datetime.datetime.strptime(reformatted, '%Y-%m-%d')
                    else:
                        date_obj = datetime.datetime.strptime(text, fmt)
                    
                    return date_obj.strftime('%Y-%m-%d')
                except ValueError:
                    continue
        
        return None
    
    def set_today(self):
        """設置為今天"""
        today = datetime.datetime.now().strftime('%Y-%m-%d')
        self.entry.delete(0, tk.END)
        self.entry.insert(0, today)
        self.entry['fg'] = self.entry.default_fg_color
    
    def set_yesterday(self):
        """設置為昨天"""
        yesterday = (datetime.datetime.now() - datetime.timedelta(days=1)).strftime('%Y-%m-%d')
        self.entry.delete(0, tk.END)
        self.entry.insert(0, yesterday)
        self.entry['fg'] = self.entry.default_fg_color
    
    def clear_date(self):
        """清空日期"""
        self.entry.delete(0, tk.END)
        self.entry.put_placeholder()
    
    def get_date(self):
        """獲取日期"""
        return self.entry.get_value()
    
    def set_date(self, date_str):
        """設置日期"""
        if date_str:
            self.entry.delete(0, tk.END)
            self.entry.insert(0, str(date_str))
            self.entry['fg'] = self.entry.default_fg_color
        else:
            self.clear_date()