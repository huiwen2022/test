import tkinter as tk
from tkinter import ttk, messagebox
from enhanced_input_utils import PlaceholderEntry

class PlaceholderText(tk.Text):
    """帶有提示文字的多行文字控件"""
    
    def __init__(self, master=None, placeholder="", placeholder_color="gray", **kw):
        super().__init__(master, **kw)
        
        self.placeholder = placeholder
        self.placeholder_color = placeholder_color
        self.default_fg_color = self['fg'] or 'black'
        
        self.bind("<FocusIn>", self.focus_in)
        self.bind("<FocusOut>", self.focus_out)
        self.bind("<Key>", self.on_key_press)
        
        self.put_placeholder()

    def put_placeholder(self):
        """顯示提示文字"""
        current_content = self.get("1.0", "end-1c")
        if not current_content:
            self.insert("1.0", self.placeholder)
            self.configure(fg=self.placeholder_color)

    def focus_in(self, event=None):
        """獲得焦點時清除提示文字"""
        if self.get("1.0", "end-1c") == self.placeholder:
            self.delete("1.0", "end")
            self.configure(fg=self.default_fg_color)

    def focus_out(self, event=None):
        """失去焦點時恢復提示文字"""
        self.put_placeholder()
    
    def on_key_press(self, event=None):
        """按鍵時確保文字顏色正確"""
        if self.get("1.0", "end-1c") == self.placeholder:
            self.delete("1.0", "end")
            self.configure(fg=self.default_fg_color)
    
    def get_value(self):
        """獲取實際值（排除placeholder）"""
        value = self.get("1.0", "end-1c")
        return '' if value == self.placeholder else value
    
    def set_value(self, value):
        """設置值"""
        self.delete("1.0", "end")
        if value:
            self.insert("1.0", str(value))
            self.configure(fg=self.default_fg_color)
        else:
            self.put_placeholder()

class ProductsTab:
    def __init__(self, notebook, main_app):
        self.main_app = main_app
        self.frame = ttk.Frame(notebook)
        self.data = []
        self.columns = ["產品ID", "產品名稱", "類別", "價格", "庫存", "供應商", "備註"]
        
        self.create_widgets()
    
    def create_required_field_legend(self):
        """建立必填欄位說明"""
        legend_frame = ttk.Frame(self.frame)
        legend_frame.pack(fill=tk.X, padx=10, pady=2)
        
        tk.Label(legend_frame, text="* 為必填欄位", 
                font=("Arial", 8), fg="red").pack(side=tk.RIGHT)
        tk.Label(legend_frame, text="產品名稱、類別、價格為必填項目", 
                font=("Arial", 8), fg="gray").pack(side=tk.RIGHT, padx=10)
    
    def create_widgets(self):
        # 主要框架
        main_frame = ttk.Frame(self.frame)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # 建立必填欄位說明
        self.create_required_field_legend()
        
        # 輸入區域
        input_frame = ttk.LabelFrame(main_frame, text="新增/編輯產品", padding=10)
        input_frame.pack(fill=tk.X, pady=(0, 10))
        
        # 第一行：產品ID 和 產品名稱
        ttk.Label(input_frame, text="產品ID:").grid(row=0, column=0, sticky=tk.W, padx=5, pady=2)
        self.product_id_entry = PlaceholderEntry(
            input_frame, 
            placeholder="系統自動生成或手動輸入",
            width=20
        )
        self.product_id_entry.grid(row=0, column=1, sticky=tk.W, padx=5, pady=2)
        
        ttk.Label(input_frame, text="產品名稱: *").grid(row=0, column=2, sticky=tk.W, padx=5, pady=2)
        self.product_name_entry = PlaceholderEntry(
            input_frame, 
            placeholder="請輸入產品名稱 (必填)",
            width=25
        )
        self.product_name_entry.grid(row=0, column=3, sticky=tk.W, padx=5, pady=2)
        
        # 第二行：類別 和 價格
        ttk.Label(input_frame, text="類別: *").grid(row=1, column=0, sticky=tk.W, padx=5, pady=2)
        self.category_var = tk.StringVar()
        self.category_combo = ttk.Combobox(
            input_frame, 
            textvariable=self.category_var, 
            values=["電子產品", "服飾", "食品", "文具", "家具", "運動用品", "其他"], 
            width=17, 
            state="readonly"
        )
        self.category_combo.grid(row=1, column=1, sticky=tk.W, padx=5, pady=2)
        
        ttk.Label(input_frame, text="價格: *").grid(row=1, column=2, sticky=tk.W, padx=5, pady=2)
        self.price_entry = PlaceholderEntry(
            input_frame, 
            placeholder="請輸入價格 (必填)",
            width=25
        )
        self.price_entry.grid(row=1, column=3, sticky=tk.W, padx=5, pady=2)
        
        # 第三行：庫存 和 供應商
        ttk.Label(input_frame, text="庫存:").grid(row=2, column=0, sticky=tk.W, padx=5, pady=2)
        self.stock_entry = PlaceholderEntry(
            input_frame, 
            placeholder="請輸入庫存數量 (選填)",
            width=20
        )
        self.stock_entry.grid(row=2, column=1, sticky=tk.W, padx=5, pady=2)
        
        ttk.Label(input_frame, text="供應商:").grid(row=2, column=2, sticky=tk.W, padx=5, pady=2)
        self.supplier_entry = PlaceholderEntry(
            input_frame, 
            placeholder="請輸入供應商名稱 (選填)",
            width=25
        )
        self.supplier_entry.grid(row=2, column=3, sticky=tk.W, padx=5, pady=2)
        
        # 第四行：備註 (多行文字框)
        ttk.Label(input_frame, text="備註:").grid(row=3, column=0, sticky=tk.NW, padx=5, pady=2)
        
        # 建立備註文字框的容器
        notes_container = ttk.Frame(input_frame)
        notes_container.grid(row=3, column=1, columnspan=3, sticky=tk.W+tk.E, padx=5, pady=2)
        
        # 多行文字框
        self.notes_text = PlaceholderText(
            notes_container,
            placeholder="選填：產品相關備註說明\n可輸入多行文字...",
            height=4,
            width=60,
            wrap=tk.WORD,
            font=("Arial", 9)
        )
        self.notes_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        # 備註文字框的滾動條
        notes_scrollbar = ttk.Scrollbar(notes_container, orient=tk.VERTICAL, command=self.notes_text.yview)
        self.notes_text.configure(yscrollcommand=notes_scrollbar.set)
        notes_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        # 設置欄位擴展
        input_frame.grid_columnconfigure(3, weight=1)
        
        # 按鈕區域
        btn_frame = ttk.Frame(input_frame)
        btn_frame.grid(row=4, column=0, columnspan=4, pady=10)
        
        ttk.Button(btn_frame, text="新增產品", command=self.add_product).pack(side=tk.LEFT, padx=5)
        ttk.Button(btn_frame, text="更新產品", command=self.update_product).pack(side=tk.LEFT, padx=5)
        ttk.Button(btn_frame, text="刪除產品", command=self.delete_product).pack(side=tk.LEFT, padx=5)
        ttk.Button(btn_frame, text="清空輸入", command=self.clear_inputs).pack(side=tk.LEFT, padx=5)
        
        # 搜尋區域
        search_frame = ttk.Frame(main_frame)
        search_frame.pack(fill=tk.X, pady=(0, 5))
        
        ttk.Label(search_frame, text="搜尋:").pack(side=tk.LEFT, padx=5)
        self.search_entry = PlaceholderEntry(
            search_frame,
            placeholder="輸入關鍵字搜尋產品名稱、類別或供應商...",
            width=40
        )
        self.search_entry.pack(side=tk.LEFT, padx=5)
        self.search_entry.bind("<KeyRelease>", self.on_search)
        
        ttk.Button(search_frame, text="清除搜尋", command=self.clear_search).pack(side=tk.LEFT, padx=5)
        
        # 資料表格區域
        table_frame = ttk.LabelFrame(main_frame, text="產品列表", padding=10)
        table_frame.pack(fill=tk.BOTH, expand=True)
        
        # 創建Treeview - 支援自動調整行高
        self.tree = ttk.Treeview(
            table_frame, 
            columns=self.columns, 
            show="headings", 
            height=12
        )
        
        # 設置欄位標題和寬度
        column_widths = [100, 150, 100, 80, 60, 120, 300]  # 備註欄位加寬
        for i, col in enumerate(self.columns):
            self.tree.heading(col, text=col)
            if col == "價格":
                self.tree.column(col, width=column_widths[i], anchor=tk.E)  # 價格右對齊
            elif col == "庫存":
                self.tree.column(col, width=column_widths[i], anchor=tk.CENTER)
            else:
                self.tree.column(col, width=column_widths[i], anchor=tk.W)  # 其他左對齊
        
        # 添加滾動條
        v_scrollbar = ttk.Scrollbar(table_frame, orient=tk.VERTICAL, command=self.tree.yview)
        self.tree.configure(yscrollcommand=v_scrollbar.set)
        h_scrollbar = ttk.Scrollbar(table_frame, orient=tk.HORIZONTAL, command=self.tree.xview)
        self.tree.configure(xscrollcommand=h_scrollbar.set)
        
        self.tree.grid(row=0, column=0, sticky=tk.NSEW)
        v_scrollbar.grid(row=0, column=1, sticky=tk.NS)
        h_scrollbar.grid(row=1, column=0, sticky=tk.EW)
        
        table_frame.grid_rowconfigure(0, weight=1)
        table_frame.grid_columnconfigure(0, weight=1)
        
        # 綁定雙擊事件
        self.tree.bind("<Double-1>", self.on_item_select)
        
        # 右鍵選單
        self.create_context_menu()
        
        self.selected_item = None
    
    def create_context_menu(self):
        """建立右鍵選單"""
        self.context_menu = tk.Menu(self.tree, tearoff=0)
        self.context_menu.add_command(label="編輯", command=self.edit_selected_item)
        self.context_menu.add_command(label="刪除", command=self.delete_product)
        self.context_menu.add_separator()
        self.context_menu.add_command(label="複製產品", command=self.copy_selected_item)
        self.context_menu.add_command(label="查看完整備註", command=self.show_full_notes)
        
        self.tree.bind("<Button-3>", self.show_context_menu)
    
    def show_context_menu(self, event):
        """顯示右鍵選單"""
        item = self.tree.selection()
        if item:
            self.context_menu.post(event.x_root, event.y_root)
    
    def show_full_notes(self):
        """顯示完整備註內容"""
        selected = self.tree.selection()
        if not selected:
            return
        
        item_values = self.tree.item(selected[0], 'values')
        product_name = item_values[1]
        notes = item_values[6]
        
        # 建立新視窗顯示完整備註
        notes_window = tk.Toplevel(self.frame)
        notes_window.title(f"產品備註 - {product_name}")
        notes_window.geometry("500x300")
        notes_window.resizable(True, True)
        
        # 建立文字框顯示備註
        text_frame = ttk.Frame(notes_window)
        text_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        text_widget = tk.Text(text_frame, wrap=tk.WORD, font=("Arial", 10))
        text_widget.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        scrollbar = ttk.Scrollbar(text_frame, orient=tk.VERTICAL, command=text_widget.yview)
        text_widget.configure(yscrollcommand=scrollbar.set)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        text_widget.insert("1.0", notes if notes else "無備註")
        text_widget.config(state=tk.DISABLED)  # 只讀
        
        # 關閉按鈕
        ttk.Button(notes_window, text="關閉", command=notes_window.destroy).pack(pady=5)
    
    def calculate_row_height(self, text):
        """根據文字內容計算所需的行高"""
        if not text:
            return 25  # 預設最小行高
        
        # 如果沒有換行符號，就是單行文字
        if '\n' not in text:
            return 25  # 單行使用標準行高
        
        lines = text.split('\n')
        line_count = len(lines)
        
        # 檢查是否有超長的行需要換行（根據備註欄寬度300px估算）
        max_chars_per_line = 35  # 根據備註欄寬度和字體大小估算
        for line in lines:
            if len(line) > max_chars_per_line:
                # 計算這一行會被自動換成幾行
                wrapped_lines = (len(line) + max_chars_per_line - 1) // max_chars_per_line
                line_count += wrapped_lines - 1
        
        # 每行大約需要18像素高度，加上一些間距
        return max(25, line_count * 18 + 8)
    
    def insert_item_with_height(self, values):
        """插入項目並設定適當的行高"""
        # 插入項目到表格
        item_id = self.tree.insert("", tk.END, values=values)
        
        # 根據備註內容計算並設定行高（目前Tkinter不支援個別行高，但保留邏輯供未來使用）
        notes = values[6] if len(values) > 6 else ""
        row_height = self.calculate_row_height(notes)
        
        # 設定標籤（移除有問題的 self.tree.set 行）
        self.tree.item(item_id, tags=(f"height_{item_id}",))
        
        return item_id
    
    def update_all_row_heights(self):
        """動態更新表格行高 - 根據實際內容需求"""
        if not self.tree.get_children():
            # 如果沒有資料，設定預設行高
            style = ttk.Style()
            style.configure("Auto.Treeview", rowheight=25)
            self.tree.configure(style="Auto.Treeview")
            return
        
        # 檢查是否有多行備註
        has_multiline = False
        max_height = 25
        
        for item in self.tree.get_children():
            values = self.tree.item(item, 'values')
            if len(values) > 6:
                notes = values[6]
                if notes and '\n' in notes:
                    has_multiline = True
                    height = self.calculate_row_height(notes)
                    max_height = max(max_height, height)
        
        # 如果沒有任何多行備註，使用標準行高
        if not has_multiline:
            row_height = 25
        else:
            # 有多行備註時，使用計算出的最適高度，但限制最大值
            row_height = min(max_height, 80)  # 限制最大行高為80像素
        
        # 設定統一的行高
        style = ttk.Style()
        style.configure("Auto.Treeview", rowheight=row_height)
        self.tree.configure(style="Auto.Treeview")
    
    def validate_required_fields(self):
        """驗證必填欄位"""
        errors = []
        
        # 檢查產品名稱
        if not self.product_name_entry.get_value().strip():
            errors.append("產品名稱為必填項目")
        
        # 檢查類別
        if not self.category_var.get().strip():
            errors.append("請選擇產品類別")
        
        # 檢查價格
        price = self.price_entry.get_value().strip()
        if not price:
            errors.append("價格為必填項目")
        else:
            try:
                price_value = float(price)
                if price_value < 0:
                    errors.append("價格不能為負數")
            except ValueError:
                errors.append("價格格式不正確，請輸入有效數字")
        
        return errors
    
    def highlight_required_fields(self, show_error=False):
        """高亮顯示必填欄位"""
        if show_error:
            # 錯誤狀態：紅色邊框
            error_style = {"highlightbackground": "red", "highlightcolor": "red", "highlightthickness": 2}
            
            if not self.product_name_entry.get_value().strip():
                self.product_name_entry.config(**error_style)
            else:
                self.product_name_entry.config(highlightthickness=0)
                
            if not self.category_var.get().strip():
                self.category_combo.config(highlightbackground="red", highlightcolor="red", highlightthickness=2)
            else:
                self.category_combo.config(highlightthickness=0)
                
            if not self.price_entry.get_value().strip():
                self.price_entry.config(**error_style)
            else:
                self.price_entry.config(highlightthickness=0)
        else:
            # 正常狀態：移除高亮
            self.product_name_entry.config(highlightthickness=0)
            self.category_combo.config(highlightthickness=0)
            self.price_entry.config(highlightthickness=0)
    
    def add_product(self):
        """新增產品"""
        # 先移除之前的錯誤高亮
        self.highlight_required_fields(False)
        
        # 驗證必填欄位
        errors = self.validate_required_fields()
        if errors:
            self.highlight_required_fields(True)
            messagebox.showerror("驗證錯誤", "\n".join(f"• {error}" for error in errors))
            return
        
        # 獲取輸入值
        product_id = self.product_id_entry.get_value().strip()
        product_name = self.product_name_entry.get_value().strip()
        category = self.category_var.get().strip()
        price = self.price_entry.get_value().strip()
        stock = self.stock_entry.get_value().strip()
        supplier = self.supplier_entry.get_value().strip()
        notes = self.notes_text.get_value().strip()
        
        # 格式化價格
        price_value = float(price)
        price = f"{price_value:.2f}"
        
        # 驗證庫存格式（選填）
        if stock:
            try:
                stock_value = int(stock)
                if stock_value < 0:
                    messagebox.showerror("錯誤", "庫存不能為負數！")
                    return
                stock = str(stock_value)
            except ValueError:
                messagebox.showerror("錯誤", "庫存必須為整數！")
                self.stock_entry.focus()
                return
        
        # 自動生成產品ID（如果為空）
        if not product_id:
            product_id = f"P{len(self.data) + 1:04d}"
        
        # 檢查ID是否已存在
        if any(item[0] == product_id for item in self.data):
            messagebox.showerror("錯誤", f"產品ID '{product_id}' 已存在！請使用不同的ID。")
            self.product_id_entry.focus()
            return
        
        # 添加到資料列表
        product_data = [product_id, product_name, category, price, stock, supplier, notes]
        self.data.append(product_data)
        
        # 使用新的插入方法添加到表格
        item_id = self.insert_item_with_height(product_data)
        
        # 更新所有行高
        self.update_all_row_heights()
        
        # 選中新添加的項目
        self.tree.selection_set(item_id)
        self.tree.see(item_id)
        
        # 清空輸入欄位
        self.clear_inputs()
        
        # 儲存資料
        self.main_app.save_data()
        
        messagebox.showinfo("成功", f"產品 '{product_name}' 新增成功！")
    
    def update_product(self):
        """更新產品"""
        selected = self.tree.selection()
        if not selected:
            messagebox.showwarning("警告", "請先選擇要更新的產品！")
            return
        
        # 先移除之前的錯誤高亮
        self.highlight_required_fields(False)
        
        # 驗證必填欄位
        errors = self.validate_required_fields()
        if errors:
            self.highlight_required_fields(True)
            messagebox.showerror("驗證錯誤", "\n".join(f"• {error}" for error in errors))
            return
        
        # 獲取選中項目的索引
        item_index = self.tree.index(selected[0])
        
        # 獲取輸入值
        product_id = self.product_id_entry.get_value().strip()
        product_name = self.product_name_entry.get_value().strip()
        category = self.category_var.get().strip()
        price = self.price_entry.get_value().strip()
        stock = self.stock_entry.get_value().strip()
        supplier = self.supplier_entry.get_value().strip()
        notes = self.notes_text.get_value().strip()
        
        # 格式化價格
        price_value = float(price)
        price = f"{price_value:.2f}"
        
        # 驗證庫存格式（選填）
        if stock:
            try:
                stock_value = int(stock)
                if stock_value < 0:
                    messagebox.showerror("錯誤", "庫存不能為負數！")
                    return
                stock = str(stock_value)
            except ValueError:
                messagebox.showerror("錯誤", "庫存必須為整數！")
                return
        
        # 檢查ID衝突（除了當前項目）
        if any(i != item_index and item[0] == product_id for i, item in enumerate(self.data)):
            messagebox.showerror("錯誤", f"產品ID '{product_id}' 已存在！")
            return
        
        # 更新資料
        product_data = [product_id, product_name, category, price, stock, supplier, notes]
        self.data[item_index] = product_data
        
        # 更新表格顯示
        self.tree.item(selected[0], values=product_data)
        
        # 更新所有行高
        self.update_all_row_heights()
        
        # 清空輸入
        self.clear_inputs()
        
        # 儲存資料
        self.main_app.save_data()
        
        messagebox.showinfo("成功", f"產品 '{product_name}' 更新成功！")
    
    def delete_product(self):
        """刪除產品"""
        selected = self.tree.selection()
        if not selected:
            messagebox.showwarning("警告", "請先選擇要刪除的產品！")
            return
        
        # 獲取選中項目的資料
        item_index = self.tree.index(selected[0])
        product_name = self.data[item_index][1]
        
        # 確認刪除
        if messagebox.askyesno("確認刪除", f"確定要刪除產品 '{product_name}' 嗎？\n此操作無法復原！"):
            
            # 從資料列表中刪除
            del self.data[item_index]
            
            # 從表格中刪除
            self.tree.delete(selected[0])
            
            # 更新行高
            self.update_all_row_heights()
            
            # 清空輸入
            self.clear_inputs()
            
            # 儲存資料
            self.main_app.save_data()
            
            messagebox.showinfo("成功", f"產品 '{product_name}' 已刪除！")
    
    def on_item_select(self, event):
        """雙擊選中項目時載入到輸入欄位"""
        selected = self.tree.selection()
        if selected:
            item_index = self.tree.index(selected[0])
            item_data = self.data[item_index]  # 使用原始資料，包含完整備註
            
            # 載入資料到輸入欄位
            self.product_id_entry.set_value(item_data[0])
            self.product_name_entry.set_value(item_data[1])
            self.category_var.set(item_data[2])
            self.price_entry.set_value(item_data[3])
            self.stock_entry.set_value(item_data[4])
            self.supplier_entry.set_value(item_data[5])
            self.notes_text.set_value(item_data[6])  # 載入完整備註
            
            self.selected_item = selected[0]
    
    def edit_selected_item(self):
        """編輯選中的項目"""
        selected = self.tree.selection()
        if selected:
            self.on_item_select(None)  # 載入資料到輸入欄位
    
    def copy_selected_item(self):
        """複製選中的項目"""
        selected = self.tree.selection()
        if selected:
            item_index = self.tree.index(selected[0])
            item_data = self.data[item_index]
            
            # 載入資料但修改ID和名稱
            self.product_id_entry.set_value("")  # 清空ID讓系統自動生成
            self.product_name_entry.set_value(f"{item_data[1]} (複製)")
            self.category_var.set(item_data[2])
            self.price_entry.set_value(item_data[3])
            self.stock_entry.set_value(item_data[4])
            self.supplier_entry.set_value(item_data[5])
            self.notes_text.set_value(item_data[6])
    
    def clear_inputs(self):
        """清空所有輸入欄位"""
        # 移除錯誤高亮
        self.highlight_required_fields(False)
        
        self.product_id_entry.set_value("")
        self.product_name_entry.set_value("")
        self.category_var.set("")
        self.price_entry.set_value("")
        self.stock_entry.set_value("")
        self.supplier_entry.set_value("")
        self.notes_text.set_value("")  # 清空多行備註
        
        self.selected_item = None
    
    def on_search(self, event=None):
        """搜尋功能"""
        keyword = self.search_entry.get_value().strip().lower()
        self.search_products(keyword)
    
    def clear_search(self):
        """清除搜尋"""
        self.search_entry.set_value("")
        self.search_products("")
    
    def search_products(self, keyword):
        """搜尋產品"""
        # 清空現有表格
        for item in self.tree.get_children():
            self.tree.delete(item)
        
        if not keyword:
            # 如果關鍵字為空，顯示所有資料
            for item_data in self.data:
                self.insert_item_with_height(item_data)
        else:
            # 搜尋並顯示符合的項目
            for item_data in self.data:
                # 在產品名稱、類別、供應商、備註中搜尋
                if (keyword in item_data[1].lower() or 
                    keyword in item_data[2].lower() or 
                    keyword in item_data[5].lower() or
                    keyword in item_data[6].lower()):
                    self.insert_item_with_height(item_data)
        
        # 更新所有行高
        self.update_all_row_heights()
    
    def get_data(self):
        """獲取所有產品資料"""
        return self.data.copy()
    
    def load_data_from_list(self, data_list):
        """從列表載入資料"""
        self.data = data_list.copy()
        
        # 清空現有表格
        for item in self.tree.get_children():
            self.tree.delete(item)
        
        # 載入新資料
        for item_data in self.data:
            self.insert_item_with_height(item_data)
        
        # 更新所有行高
        self.update_all_row_heights()
    
    def load_sample_data(self):
        """載入範例資料"""
        sample_data = [
            ["P0001", "iPhone 15 Pro", "電子產品", "39900.00", "50", "蘋果公司", "最新款智慧手機\n配備A17 Pro晶片\n支援5G網路\n128GB儲存空間"],
            ["P0002", "MacBook Pro 14吋", "電子產品", "65900.00", "20", "蘋果公司", "高效能筆記型電腦，M3 Pro晶片"],
            ["P0003", "Sony WH-1000XM5", "電子產品", "10900.00", "100", "Sony", "無線降噪耳機\n業界領先降噪技術\n30小時電池續航"],
            ["P0004", "Nike Air Max 270", "服飾", "4200.00", "80", "Nike", "經典運動鞋，舒適透氣"],
            ["P0005", "星巴克精選咖啡豆", "食品", "450.00", "200", "星巴克", "100%阿拉比卡咖啡豆\n中度烘焙\n1磅裝"],
            ["P0006", "無印良品原子筆", "文具", "15.00", "500", "無印良品", "簡約設計，書寫流暢"],
            ["P0007", "IKEA書桌", "家具", "2990.00", "15", "IKEA", "現代簡約風格\n120cm x 60cm\n白色桌面\n可調節桌腳高度"],
        ]
        
        self.load_data_from_list(sample_data)
    
    def clear_all_data(self):
        """清除所有資料"""
        self.data.clear()
        
        # 清空表格
        for item in self.tree.get_children():
            self.tree.delete(item)
        
        # 清空輸入欄位
        self.clear_inputs()
        
        # 清空搜尋
        self.search_entry.set_value("")
        
        # 重設行高
        style = ttk.Style()
        style.configure("Auto.Treeview", rowheight=25)
        self.tree.configure(style="Auto.Treeview")