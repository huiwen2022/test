import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import os
import sys
# 取得 libs 資料夾的絕對路徑並加到 sys.path
sys.path.append(os.path.join(os.path.dirname(__file__), "libs"))
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment
from openpyxl.utils import get_column_letter
import re

class CustomersTab:
    def __init__(self, parent, main_app):
        self.parent = parent
        self.main_app = main_app
        self.data = []
        self.columns = ["客戶編號", "客戶名稱", "聯絡人", "電話", "Email", "地址", "備註"]
        
        # 必填欄位定義
        self.required_fields = ["客戶編號", "客戶名稱", "聯絡人"]
        
        # 創建主框架
        self.frame = ttk.Frame(parent)
        self.setup_ui()
    
    def setup_ui(self):
        """設置用戶介面"""
        # 使用PanedWindow分割上下兩部分
        self.paned_window = ttk.PanedWindow(self.frame, orient=tk.VERTICAL)
        self.paned_window.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # 上半部分：資料顯示區域
        self.setup_data_display()
        
        # 下半部分：編輯區域
        self.setup_edit_area()
        
        # 設置分割比例 - 延遲執行確保視窗已完全載入
        self.frame.after(200, self.set_paned_position)
    
    def setup_data_display(self):
        """設置資料顯示區域（上半部分）"""
        # 上半部分框架
        self.top_frame = ttk.Frame(self.paned_window)
        self.paned_window.add(self.top_frame, weight=3)
        
        # 工具欄
        toolbar = ttk.Frame(self.top_frame)
        toolbar.pack(fill=tk.X, padx=5, pady=5)
        
        ttk.Button(toolbar, text="刪除選中", command=self.delete_row).pack(side=tk.LEFT, padx=2)
        ttk.Button(toolbar, text="複製選中", command=self.copy_row).pack(side=tk.LEFT, padx=2)
        ttk.Button(toolbar, text="清除全部", command=self.clear_all_data).pack(side=tk.LEFT, padx=2)
        ttk.Separator(toolbar, orient="vertical").pack(side=tk.LEFT, padx=10, fill=tk.Y)
        ttk.Button(toolbar, text="匯出Excel", command=self.export_to_excel).pack(side=tk.LEFT, padx=2)
        
        # 創建Treeview框架
        self.tree_frame = ttk.Frame(self.top_frame)
        self.tree_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # 創建Treeview
        self.tree = ttk.Treeview(self.tree_frame, columns=self.columns, show="headings", height=12)
        
        # 設置列標題和固定欄寬
        column_widths = [100, 150, 100, 120, 200, 200, 150]
        for i, col in enumerate(self.columns):
            self.tree.heading(col, text=col)
            self.tree.column(col, width=column_widths[i], minwidth=column_widths[i], anchor="w")
        
        # 設置樣式
        self.setup_treeview_style()
        
        # 滾動條
        v_scrollbar = ttk.Scrollbar(self.tree_frame, orient="vertical", command=self.tree.yview)
        h_scrollbar = ttk.Scrollbar(self.tree_frame, orient="horizontal", command=self.tree.xview)
        self.tree.configure(yscrollcommand=v_scrollbar.set, xscrollcommand=h_scrollbar.set)
        
        # 佈局
        self.tree.grid(row=0, column=0, sticky="nsew")
        v_scrollbar.grid(row=0, column=1, sticky="ns")
        h_scrollbar.grid(row=1, column=0, sticky="ew")
        
        self.tree_frame.grid_rowconfigure(0, weight=1)
        self.tree_frame.grid_columnconfigure(0, weight=1)
        
        # 選中事件
        self.tree.bind("<<TreeviewSelect>>", self.on_select)
    
    def setup_treeview_style(self):
        """設置Treeview樣式"""
        style = ttk.Style()
        
        # 設置標題樣式
        style.configure("Treeview.Heading", 
                       font=("Arial", 9, "bold"),
                       relief="solid",
                       borderwidth=1)
        
        # 設置一般行樣式
        style.configure("Treeview", 
                       font=("Arial", 9),
                       rowheight=30)  # 增加行高以支援多行文字
        
        # 設置標籤樣式
        self.tree.tag_configure("even", background="#E6F3FF")  # 偶數行粉藍色
        self.tree.tag_configure("odd", background="white")     # 奇數行白色
    
    def set_paned_position(self):
        """設置分割視窗位置"""
        try:
            # 設置上半部分占約55%的高度，給編輯區域更多空間
            total_height = self.paned_window.winfo_height()
            if total_height > 100:  # 確保視窗已經正確載入
                self.paned_window.sashpos(0, int(total_height * 0.55))
            else:
                # 如果高度還沒確定，再次延遲執行
                self.frame.after(200, self.set_paned_position)
        except:
            # 如果設置失敗，使用固定值
            self.paned_window.sashpos(0, 300)
    
    def setup_edit_area(self):
        """設置編輯區域（下半部分）"""
        # 下半部分框架
        self.bottom_frame = ttk.Frame(self.paned_window)
        self.paned_window.add(self.bottom_frame, weight=1)
        
        # 標題
        ttk.Label(self.bottom_frame, text="客戶資料編輯", font=("Arial", 12, "bold")).pack(pady=5)
        
        # 創建可滾動的編輯區域
        self.canvas = tk.Canvas(self.bottom_frame)
        self.scrollbar = ttk.Scrollbar(self.bottom_frame, orient="vertical", command=self.canvas.yview)
        self.scrollable_frame = ttk.Frame(self.canvas)
        
        self.scrollable_frame.bind(
            "<Configure>",
            lambda e: self.canvas.configure(scrollregion=self.canvas.bbox("all"))
        )
        
        self.canvas.create_window((0, 0), window=self.scrollable_frame, anchor="nw")
        self.canvas.configure(yscrollcommand=self.scrollbar.set)
        
        # 編輯表單框架（放在可滾動框架內）
        self.edit_frame = ttk.Frame(self.scrollable_frame)
        self.edit_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)
        
        # 創建輸入欄位
        self.entries = {}
        self.create_input_fields()
        
        # 按鈕框架（放在可滾動框架內）
        button_frame = ttk.Frame(self.scrollable_frame)
        button_frame.pack(pady=10)
        
        ttk.Button(button_frame, text="新增客戶", command=self.add_row).pack(side=tk.LEFT, padx=5)
        ttk.Button(button_frame, text="修改客戶", command=self.update_row).pack(side=tk.LEFT, padx=5)
        ttk.Button(button_frame, text="清空表單", command=self.clear_form).pack(side=tk.LEFT, padx=5)
        
        # 佈局滾動區域
        self.canvas.pack(side="left", fill="both", expand=True)
        self.scrollbar.pack(side="right", fill="y")
        
        # 綁定滑鼠滾輪事件
        def _on_mousewheel(event):
            self.canvas.yview_scroll(int(-1*(event.delta/120)), "units")
        self.canvas.bind("<MouseWheel>", _on_mousewheel)
        
        # 目前編輯的項目ID
        self.current_editing_item = None
    
    def create_input_fields(self):
        """創建輸入欄位"""
        for i, col in enumerate(self.columns):
            if col in ["地址", "備註"]:
                # 地址和備註占整行
                row = i + (1 if i > 4 else 0)  # 調整行位置
                column = 0
                columnspan = 4
            else:
                row = i // 2
                column = (i % 2) * 2
                columnspan = 1
            
            # 標籤
            label_text = col
            if col in self.required_fields:
                label_text += " *"
            
            label = ttk.Label(self.edit_frame, text=f"{label_text}:")
            if columnspan == 4:
                label.grid(row=row, column=0, padx=5, pady=3, sticky="nw")
            else:
                label.grid(row=row, column=column, padx=5, pady=3, sticky="w")
            
            # 輸入欄位
            if col in ["地址", "備註"]:
                # 多行文字框
                entry = tk.Text(self.edit_frame, width=60, height=3)
            else:
                # 一般輸入框
                entry = ttk.Entry(self.edit_frame, width=30)
            
            if columnspan == 4:
                entry.grid(row=row+1, column=0, columnspan=4, padx=5, pady=3, sticky="ew")
            else:
                entry.grid(row=row, column=column+1, padx=5, pady=3, sticky="w")
            
            self.entries[col] = entry
        
        # 必填提示
        required_label = ttk.Label(self.edit_frame, text="* 為必填欄位", foreground="red", font=("Arial", 8))
        required_label.grid(row=len(self.columns) + 2, column=0, columnspan=4, pady=5)
    
    def on_select(self, event):
        """當選中項目時，載入資料到編輯區"""
        selected = self.tree.selection()
        if selected:
            item = self.tree.item(selected[0])
            values = item['values']
            self.load_data_to_form(values)
            self.current_editing_item = selected[0]
    
    def load_data_to_form(self, values):
        """載入資料到表單"""
        for i, col in enumerate(self.columns):
            entry = self.entries[col]
            
            if isinstance(entry, tk.Text):
                entry.delete("1.0", tk.END)
                entry.insert("1.0", str(values[i]))
            else:
                entry.delete(0, tk.END)
                entry.insert(0, str(values[i]))
    
    def get_form_data(self):
        """從表單獲取資料"""
        data = []
        for col in self.columns:
            entry = self.entries[col]
            
            if isinstance(entry, tk.Text):
                value = entry.get("1.0", "end-1c").strip()
            else:
                value = entry.get().strip()
            
            data.append(value)
        return data
    
    def validate_form_data(self, data):
        """驗證表單資料"""
        for i, col in enumerate(self.columns):
            # 必填欄位檢查
            if col in self.required_fields and not data[i]:
                messagebox.showerror("錯誤", f"{col} 為必填欄位")
                return False
            
            # Email格式檢查
            if col == "Email" and data[i]:
                email_pattern = re.compile(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$')
                if not email_pattern.match(data[i]):
                    messagebox.showerror("錯誤", "Email格式不正確")
                    return False
            
            # 電話格式檢查（簡單檢查）
            if col == "電話" and data[i]:
                phone_pattern = re.compile(r'^[\d\-\+\(\)\s]+$')
                if not phone_pattern.match(data[i]):
                    messagebox.showerror("錯誤", "電話格式不正確")
                    return False
        
        return True
    
    def clear_form(self):
        """清空表單"""
        for col in self.columns:
            entry = self.entries[col]
            
            if isinstance(entry, tk.Text):
                entry.delete("1.0", tk.END)
            else:
                entry.delete(0, tk.END)
        
        self.current_editing_item = None
    
    def update_row_colors(self):
        """更新行顏色"""
        for i, item in enumerate(self.tree.get_children()):
            if i % 2 == 1:  # 偶數行（從0開始計算，所以奇數索引是偶數行）
                self.tree.item(item, tags=("even",))
            else:
                self.tree.item(item, tags=("odd",))
    
    def add_row(self):
        """新增資料"""
        data = self.get_form_data()
        
        if not self.validate_form_data(data):
            return
        
        # 檢查客戶編號是否重複
        for existing_data in self.data:
            if existing_data[0] == data[0]:
                messagebox.showerror("錯誤", "客戶編號已存在")
                return
        
        # 新增到資料和樹狀檢視
        self.data.append(data)
        self.tree.insert("", "end", values=data)
        
        # 更新行顏色
        self.update_row_colors()
        
        # 清空表單
        self.clear_form()
        
        # 儲存資料
        self.main_app.save_data()
        
        messagebox.showinfo("成功", "客戶已新增")
    
    def update_row(self):
        """修改資料"""
        if not self.current_editing_item:
            messagebox.showwarning("警告", "請先選擇要修改的客戶")
            return
        
        data = self.get_form_data()
        
        if not self.validate_form_data(data):
            return
        
        # 獲取原始資料
        old_values = self.tree.item(self.current_editing_item)['values']
        
        # 如果客戶編號改變，檢查是否重複
        if data[0] != old_values[0]:
            for existing_data in self.data:
                if existing_data[0] == data[0]:
                    messagebox.showerror("錯誤", "客戶編號已存在")
                    return
        
        # 更新資料
        if list(old_values) in self.data:
            index = self.data.index(list(old_values))
            self.data[index] = data
        
        # 更新樹狀檢視
        self.tree.item(self.current_editing_item, values=data)
        
        # 更新行顏色
        self.update_row_colors()
        
        # 清空表單
        self.clear_form()
        
        # 儲存資料
        self.main_app.save_data()
        
        messagebox.showinfo("成功", "客戶已修改")
    
    def delete_row(self):
        """刪除選中的資料"""
        selected = self.tree.selection()
        if not selected:
            messagebox.showwarning("警告", "請先選擇要刪除的客戶")
            return
        
        if messagebox.askyesno("確認", "確定要刪除選中的客戶嗎？"):
            for item in selected:
                # 從data中移除
                values = self.tree.item(item)['values']
                if list(values) in self.data:
                    self.data.remove(list(values))
                # 從tree中移除
                self.tree.delete(item)
            
            # 更新行顏色
            self.update_row_colors()
            
            # 清空表單
            self.clear_form()
            
            # 儲存資料
            self.main_app.save_data()
    
    def copy_row(self):
        """複製選中的資料"""
        selected = self.tree.selection()
        if not selected:
            messagebox.showwarning("警告", "請先選擇要複製的客戶")
            return
        
        item = self.tree.item(selected[0])
        values = list(item['values'])
        
        # 修改編號避免重複
        original_id = values[0]
        counter = 1
        while True:
            new_id = f"{original_id}_copy{counter}"
            # 檢查是否重複
            exists = False
            for existing_data in self.data:
                if existing_data[0] == new_id:
                    exists = True
                    break
            if not exists:
                values[0] = new_id
                break
            counter += 1
        
        # 新增資料
        self.data.append(values)
        self.tree.insert("", "end", values=values)
        
        # 更新行顏色
        self.update_row_colors()
        
        # 儲存資料
        self.main_app.save_data()
    
    def clear_all_data(self):
        """清除所有資料"""
        if messagebox.askyesno("確認", "確定要清除所有客戶資料嗎？"):
            self.data.clear()
            for item in self.tree.get_children():
                self.tree.delete(item)
            self.clear_form()
            self.main_app.save_data()
    
    def load_sample_data(self):
        """載入範例資料"""
        if not self.data:  # 只有在沒有資料時才載入範例
            sample_data = [
                ["C001", "台北科技公司", "王經理", "02-12345678", "wang@taipei-tech.com", "台北市信義區\n忠孝東路五段", "重要客戶\n長期合作夥伴"],
                ["C002", "高雄貿易商行", "李老闆", "07-87654321", "li@kaohsiung.com", "高雄市前金區\n中正四路", "長期合作\n信用良好"],
                ["C003", "台中製造廠", "陳廠長", "04-11223344", "chen@taichung.com", "台中市西屯區\n工業區路", "大量採購\n製造業客戶"],
            ]
            self.load_data_from_list(sample_data)
    
    def load_data_from_list(self, data_list):
        """從清單載入資料"""
        # 清空現有資料
        self.data.clear()
        for item in self.tree.get_children():
            self.tree.delete(item)
        
        # 載入新資料
        for item in data_list:
            self.data.append(item)
            self.tree.insert("", "end", values=item)
        
        # 更新行顏色
        self.update_row_colors()
    
    def export_to_excel(self):
        """匯出到Excel"""
        if not self.data:
            messagebox.showwarning("警告", "沒有資料可以匯出")
            return
        
        try:
            # 創建工作簿
            wb = Workbook()
            ws = wb.active
            ws.title = "客戶管理"
            
            # 設置標題行
            for col_num, column_title in enumerate(self.columns, 1):
                cell = ws.cell(row=1, column=col_num)
                cell.value = column_title
                # 前5欄藍底白字，其他橘底黑字
                if col_num <= 5:
                    cell.fill = PatternFill(start_color="366092", end_color="366092", fill_type="solid")
                    cell.font = Font(color="FFFFFF", bold=True)
                else:
                    cell.fill = PatternFill(start_color="FFA500", end_color="FFA500", fill_type="solid")
                    cell.font = Font(color="000000", bold=True)
                cell.alignment = Alignment(horizontal="center", vertical="center")
            
            # 填入資料
            for row_num, row_data in enumerate(self.data, 2):
                for col_num, cell_value in enumerate(row_data, 1):
                    cell = ws.cell(row=row_num, column=col_num)
                    cell.value = cell_value
                    
                    # 第7欄（備註）設為黃色背景
                    if col_num == 7:
                        cell.fill = PatternFill(start_color="FFFF00", end_color="FFFF00", fill_type="solid")
                    
                    cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
            
            # 凍結第一列和第一欄
            ws.freeze_panes = "B2"
            
            # 調整欄寬和行高
            column_widths = [12, 20, 15, 15, 25, 30, 20]
            for i, width in enumerate(column_widths, 1):
                column_letter = get_column_letter(i)
                ws.column_dimensions[column_letter].width = width
            
            # 設置行高以支援多行文字
            for row in ws.iter_rows(min_row=2):
                ws.row_dimensions[row[0].row].height = 40
            
            # 選擇儲存位置
            filename = filedialog.asksaveasfilename(
                defaultextension=".xlsx",
                filetypes=[("Excel files", "*.xlsx"), ("All files", "*.*")],
                title="儲存客戶管理Excel檔案"
            )
            
            if filename:
                wb.save(filename)
                messagebox.showinfo("成功", f"已成功匯出到：{filename}")
        
        except Exception as e:
            messagebox.showerror("錯誤", f"匯出Excel時發生錯誤：{str(e)}")