import tkinter as tk
from tkinter import ttk, messagebox
import json
import os
import sys
# 取得 libs 資料夾的絕對路徑並加到 sys.path
sys.path.append(os.path.join(os.path.dirname(__file__), "libs"))
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment
from openpyxl.utils import get_column_letter

# 添加當前目錄到路徑，確保能導入其他模組
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from tab1_products import ProductsTab
from tab2_customers import CustomersTab
from tab3_orders import OrdersTab

class MainApplication:
    def __init__(self, root):
        self.root = root
        self.root.title("Excel資料管理系統")
        self.root.geometry("1200x700")
        
        # JSON資料檔案路徑
        self.data_file = "data.json"
        
        # 創建主框架
        self.main_frame = ttk.Frame(root)
        self.main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # 創建頁籤控制器
        self.notebook = ttk.Notebook(self.main_frame)
        self.notebook.pack(fill=tk.BOTH, expand=True)
        
        # 初始化頁籤
        self.init_tabs()
        
        # 添加菜單欄
        self.create_menu()
        
        # 載入資料
        self.load_data()
    
    def init_tabs(self):
        """初始化所有頁籤"""
        try:
            # 產品管理頁籤
            self.products_tab = ProductsTab(self.notebook, self)
            self.notebook.add(self.products_tab.frame, text="產品管理")
            
            # 客戶管理頁籤
            self.customers_tab = CustomersTab(self.notebook, self)
            self.notebook.add(self.customers_tab.frame, text="客戶管理")
            
            # 訂單管理頁籤
            self.orders_tab = OrdersTab(self.notebook, self)
            self.notebook.add(self.orders_tab.frame, text="訂單管理")
            
        except Exception as e:
            messagebox.showerror("錯誤", f"初始化頁籤時發生錯誤: {str(e)}")
    
    def create_menu(self):
        """創建菜單欄"""
        menubar = tk.Menu(self.root)
        self.root.config(menu=menubar)
        
        # 檔案菜單
        file_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="檔案", menu=file_menu)
        file_menu.add_command(label="匯出全部Excel", command=self.export_all_to_single_file)
        file_menu.add_separator()
        file_menu.add_command(label="清除全部資料", command=self.clear_all_data)
        file_menu.add_separator()
        file_menu.add_command(label="退出", command=self.on_closing)
        
        # 說明菜單
        help_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="說明", menu=help_menu)
        help_menu.add_command(label="關於", command=self.show_about)
    
    def save_data(self):
        """儲存所有資料到JSON檔案"""
        try:
            data = {
                "products": self.products_tab.data,
                "customers": self.customers_tab.data,
                "orders": self.orders_tab.data
            }
            with open(self.data_file, 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
        except Exception as e:
            print(f"儲存資料錯誤: {str(e)}")
    
    def load_data(self):
        """從JSON檔案載入資料"""
        try:
            if os.path.exists(self.data_file):
                with open(self.data_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                
                # 載入各頁籤資料
                if "products" in data:
                    self.products_tab.load_data_from_list(data["products"])
                if "customers" in data:
                    self.customers_tab.load_data_from_list(data["customers"])
                if "orders" in data:
                    self.orders_tab.load_data_from_list(data["orders"])
            else:
                # 如果沒有資料檔案，載入範例資料
                self.products_tab.load_sample_data()
                self.customers_tab.load_sample_data()
                self.orders_tab.load_sample_data()
        except Exception as e:
            print(f"載入資料錯誤: {str(e)}")
            # 如果載入失敗，載入範例資料
            self.products_tab.load_sample_data()
            self.customers_tab.load_sample_data()
            self.orders_tab.load_sample_data()
    
    def clear_all_data(self):
        """清除所有資料"""
        if messagebox.askyesno("確認", "確定要清除所有資料嗎？此操作無法復原！"):
            # 清除各頁籤資料
            self.products_tab.clear_all_data()
            self.customers_tab.clear_all_data()
            self.orders_tab.clear_all_data()
            
            # 刪除JSON檔案
            try:
                if os.path.exists(self.data_file):
                    os.remove(self.data_file)
                messagebox.showinfo("成功", "已清除所有資料！")
            except Exception as e:
                messagebox.showerror("錯誤", f"清除資料時發生錯誤: {str(e)}")
    
    def export_all_to_single_file(self):
        """匯出所有頁籤到單一Excel檔案"""
        try:
            from tkinter import filedialog
            
            filename = filedialog.asksaveasfilename(
                defaultextension=".xlsx",
                filetypes=[("Excel files", "*.xlsx"), ("All files", "*.*")],
                title="儲存整合Excel檔案"
            )
            
            if not filename:
                return
            
            # 創建工作簿
            wb = Workbook()
            
            # 移除預設工作表
            wb.remove(wb.active)
            
            # 定義頁籤資料和名稱
            tabs_data = [
                ("產品管理", self.products_tab.data, self.products_tab.columns),
                ("客戶管理", self.customers_tab.data, self.customers_tab.columns),
                ("訂單管理", self.orders_tab.data, self.orders_tab.columns)
            ]
            
            for sheet_name, data, columns in tabs_data:
                # 創建工作表（即使沒有資料也要創建）
                ws = wb.create_sheet(title=sheet_name)
                
                # 設置標題行（第1~5欄藍底白字，其他橘底黑字）
                for col_num, column_title in enumerate(columns, 1):
                    cell = ws.cell(row=1, column=col_num)
                    cell.value = column_title
                    
                    # 前5欄設為藍底白字
                    if col_num <= 5:
                        cell.fill = PatternFill(start_color="366092", end_color="366092", fill_type="solid")
                        cell.font = Font(color="FFFFFF", bold=True)
                    else:
                        # 其他欄位橘底黑字
                        cell.fill = PatternFill(start_color="FFA500", end_color="FFA500", fill_type="solid")
                        cell.font = Font(color="000000", bold=True)
                    
                    cell.alignment = Alignment(horizontal="center", vertical="center")
                
                # 如果有資料，填入資料
                if data:
                    for row_num, row_data in enumerate(data, 2):
                        for col_num, cell_value in enumerate(row_data, 1):
                            cell = ws.cell(row=row_num, column=col_num)
                            cell.value = cell_value
                            
                            # 第7欄設為黃色背景
                            if col_num == 7:
                                cell.fill = PatternFill(start_color="FFFF00", end_color="FFFF00", fill_type="solid")
                            
                            # 數字欄位右對齊（針對訂單管理）
                            if sheet_name == "訂單管理" and col_num in [4, 5, 6]:
                                cell.alignment = Alignment(horizontal="right", vertical="center")
                            else:
                                cell.alignment = Alignment(horizontal="center", vertical="center")
                else:
                    # 即使沒有資料，也添加一個提示行
                    cell = ws.cell(row=2, column=1)
                    cell.value = "目前沒有資料"
                    cell.alignment = Alignment(horizontal="center", vertical="center")
                    cell.font = Font(italic=True, color="999999")
                
                # 凍結第一列和第一欄
                ws.freeze_panes = "B2"
                
                # 調整欄寬
                for column in ws.columns:
                    max_length = 0
                    column_letter = get_column_letter(column[0].column)
                    for cell in column:
                        try:
                            if len(str(cell.value)) > max_length:
                                max_length = len(str(cell.value))
                        except:
                            pass
                    adjusted_width = min(max(max_length + 2, 10), 50)  # 最小寬度10，最大寬度50
                    ws.column_dimensions[column_letter].width = adjusted_width
            
            wb.save(filename)
            messagebox.showinfo("成功", f"已成功匯出整合Excel檔案到：{filename}")
        
        except Exception as e:
            messagebox.showerror("錯誤", f"匯出Excel時發生錯誤：{str(e)}")
    
    def export_all(self):
        """匯出所有頁籤的資料（舊版本，保留兼容性）"""
        self.export_all_to_single_file()
    
    def on_closing(self):
        """程式關閉時的處理"""
        self.save_data()
        self.root.quit()
    
    def show_about(self):
        """顯示關於資訊"""
        messagebox.showinfo("關於", "Excel資料管理系統 v2.0\n\n功能包含：\n- 多頁籤資料管理\n- Excel匯出功能\n- 自訂樣式格式\n- JSON資料儲存\n- 必填欄位驗證\n- 下拉選單支援")

def main():
    # 確保必要的模組存在
    required_files = ['tab1_products.py', 'tab2_customers.py', 'tab3_orders.py']
    missing_files = []
    
    for file in required_files:
        if not os.path.exists(file):
            missing_files.append(file)
    
    if missing_files:
        print(f"警告：缺少以下檔案: {', '.join(missing_files)}")
        print("請確保所有頁籤檔案都在同一目錄下")
    
    root = tk.Tk()
    app = MainApplication(root)
    
    # 設置關閉事件
    root.protocol("WM_DELETE_WINDOW", app.on_closing)
    
    root.mainloop()

if __name__ == "__main__":
    main()