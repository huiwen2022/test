import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import os
import sys
# 取得 libs 資料夾的絕對路徑並加到 sys.path
sys.path.append(os.path.join(os.path.dirname(__file__), "libs"))
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment
from openpyxl.utils import get_column_letter
from datetime import datetime

class OrdersTab:
    def __init__(self, parent, main_app):
        self.parent = parent
        self.main_app = main_app
        self.data = []
        self.columns = ["訂單編號", "客戶名稱", "產品名稱", "數量", "單價", "總金額", "訂單日期", "狀態"]
        
        # 必填欄位定義
        self.required_fields = ["訂單編號", "客戶名稱", "產品名稱", "數量", "單價"]
        
        # 下拉選單選項定義
        self.dropdown_options = {
            "狀態": ["待處理", "處理中", "待出貨", "已出貨", "已完成", "已取消"]
        }
        
        # 創建主框架
        self.frame = ttk.Frame(parent)
        self.setup_ui()
    
    def setup_ui(self):
        """設置用戶介面"""
        # 使用PanedWindow分割上下兩部分
        self.paned_window = ttk.PanedWindow(self.frame, orient=tk.VERTICAL)
        self.paned_window.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # 上半部分：資料顯示區域
        self.setup_data_display()
        
        # 下半部分：編輯區域
        self.setup_edit_area()
        
        # 設置分割比例 - 延遲執行確保視窗已完全載入
        self.frame.after(200, self.set_paned_position)
    
    def setup_data_display(self):
        """設置資料顯示區域（上半部分）"""
        # 上半部分框架
        self.top_frame = ttk.Frame(self.paned_window)
        self.paned_window.add(self.top_frame, weight=3)
        
        # 工具欄
        toolbar = ttk.Frame(self.top_frame)
        toolbar.pack(fill=tk.X, padx=5, pady=5)
        
        ttk.Button(toolbar, text="刪除選中", command=self.delete_row).pack(side=tk.LEFT, padx=2)
        ttk.Button(toolbar, text="複製選中", command=self.copy_row).pack(side=tk.LEFT, padx=2)
        ttk.Button(toolbar, text="清除全部", command=self.clear_all_data).pack(side=tk.LEFT, padx=2)
        ttk.Separator(toolbar, orient="vertical").pack(side=tk.LEFT, padx=10, fill=tk.Y)
        ttk.Button(toolbar, text="匯出Excel", command=self.export_to_excel).pack(side=tk.LEFT, padx=2)
        
        # 創建Treeview框架
        self.tree_frame = ttk.Frame(self.top_frame)
        self.tree_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # 創建Treeview
        self.tree = ttk.Treeview(self.tree_frame, columns=self.columns, show="headings", height=12)
        
        # 設置列標題和固定欄寬 - 修正：固定欄寬不可調整
        column_widths = [100, 120, 150, 80, 100, 100, 120, 100]
        for i, col in enumerate(self.columns):
            self.tree.heading(col, text=col)
            # 修正：設置固定欄寬，禁止調整大小
            self.tree.column(col, width=column_widths[i], minwidth=column_widths[i], 
                           anchor="center", stretch=False)
        
        # 設置樣式
        self.setup_treeview_style()
        
        # 滾動條
        v_scrollbar = ttk.Scrollbar(self.tree_frame, orient="vertical", command=self.tree.yview)
        h_scrollbar = ttk.Scrollbar(self.tree_frame, orient="horizontal", command=self.tree.xview)
        self.tree.configure(yscrollcommand=v_scrollbar.set, xscrollcommand=h_scrollbar.set)
        
        # 佈局
        self.tree.grid(row=0, column=0, sticky="nsew")
        v_scrollbar.grid(row=0, column=1, sticky="ns")
        h_scrollbar.grid(row=1, column=0, sticky="ew")
        
        self.tree_frame.grid_rowconfigure(0, weight=1)
        self.tree_frame.grid_columnconfigure(0, weight=1)
        
        # 選中事件
        self.tree.bind("<<TreeviewSelect>>", self.on_select)
    
    def setup_treeview_style(self):
        """設置Treeview樣式"""
        style = ttk.Style()
        
        # 修正：自定義Treeview樣式名稱避免衝突
        style_name = "Custom.Treeview"
        heading_style_name = "Custom.Treeview.Heading"
        
        # 設置標題樣式 - 修正：改用自定義樣式名稱
        style.configure(heading_style_name, 
                       font=("Arial", 10, "bold"),
                       relief="solid",
                       borderwidth=1,
                       background="#366092",  # 藍色背景
                       foreground="white")    # 白色文字
        
        # 設置一般行樣式 - 修正：增加行高支援多行文字
        style.configure(style_name, 
                       font=("Arial", 9),
                       rowheight=35)  # 增加行高支援跳行資料
        
        # 應用自定義樣式到Treeview
        self.tree.configure(style=style_name)
        
        # 設置標籤樣式 - 修正：更明確的顏色定義
        self.tree.tag_configure("even", background="#E6F3FF")         # 偶數行粉藍色
        self.tree.tag_configure("odd", background="white")           # 奇數行白色
        self.tree.tag_configure("completed", background="#E8F5E8")   # 已完成粉綠色
        self.tree.tag_configure("cancelled", background="#F0F0F0")   # 已取消淡灰色
    
    def set_paned_position(self):
        """設置分割視窗位置"""
        try:
            # 設置上半部分占約55%的高度，給編輯區域更多空間
            total_height = self.paned_window.winfo_height()
            if total_height > 100:  # 確保視窗已經正確載入
                self.paned_window.sashpos(0, int(total_height * 0.55))
            else:
                # 如果高度還沒確定，再次延遲執行
                self.frame.after(200, self.set_paned_position)
        except:
            # 如果設置失敗，使用固定值
            self.paned_window.sashpos(0, 300)
    
    def setup_edit_area(self):
        """設置編輯區域（下半部分）"""
        # 下半部分框架
        self.bottom_frame = ttk.Frame(self.paned_window)
        self.paned_window.add(self.bottom_frame, weight=1)
        
        # 標題
        ttk.Label(self.bottom_frame, text="訂單資料編輯", font=("Arial", 12, "bold")).pack(pady=5)
        
        # 創建可滾動的編輯區域
        self.canvas = tk.Canvas(self.bottom_frame)
        self.scrollbar = ttk.Scrollbar(self.bottom_frame, orient="vertical", command=self.canvas.yview)
        self.scrollable_frame = ttk.Frame(self.canvas)
        
        self.scrollable_frame.bind(
            "<Configure>",
            lambda e: self.canvas.configure(scrollregion=self.canvas.bbox("all"))
        )
        
        self.canvas.create_window((0, 0), window=self.scrollable_frame, anchor="nw")
        self.canvas.configure(yscrollcommand=self.scrollbar.set)
        
        # 編輯表單框架（放在可滾動框架內）
        self.edit_frame = ttk.Frame(self.scrollable_frame)
        self.edit_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)
        
        # 創建輸入欄位
        self.entries = {}
        self.create_input_fields()
        
        # 按鈕框架（放在可滾動框架內）
        button_frame = ttk.Frame(self.scrollable_frame)
        button_frame.pack(pady=10)
        
        ttk.Button(button_frame, text="新增訂單", command=self.add_row).pack(side=tk.LEFT, padx=5)
        ttk.Button(button_frame, text="修改訂單", command=self.update_row).pack(side=tk.LEFT, padx=5)
        ttk.Button(button_frame, text="清空表單", command=self.clear_form).pack(side=tk.LEFT, padx=5)
        
        # 佈局滾動區域
        self.canvas.pack(side="left", fill="both", expand=True)
        self.scrollbar.pack(side="right", fill="y")
        
        # 綁定滑鼠滾輪事件
        def _on_mousewheel(event):
            self.canvas.yview_scroll(int(-1*(event.delta/120)), "units")
        self.canvas.bind("<MouseWheel>", _on_mousewheel)
        
        # 目前編輯的項目ID
        self.current_editing_item = None
    
    def create_input_fields(self):
        """創建輸入欄位"""
        for i, col in enumerate(self.columns):
            row = i // 2
            column = (i % 2) * 2
            
            # 標籤
            label_text = col
            if col in self.required_fields:
                label_text += " *"
            
            label = ttk.Label(self.edit_frame, text=f"{label_text}:")
            label.grid(row=row, column=column, padx=5, pady=3, sticky="w")
            
            # 輸入欄位
            if col in self.dropdown_options:
                # 下拉選單
                entry = ttk.Combobox(self.edit_frame, values=self.dropdown_options[col], state="readonly", width=25)
                if col == "狀態":
                    entry.set("待處理")  # 預設狀態
            elif col == "訂單日期":
                # 日期欄位
                entry = ttk.Entry(self.edit_frame, width=30)
                # 預設為今天日期
                entry.insert(0, datetime.now().strftime("%Y-%m-%d"))
            elif col == "總金額":
                # 總金額為只讀欄位
                entry = ttk.Entry(self.edit_frame, width=30, state="readonly")
            else:
                # 一般輸入框
                entry = ttk.Entry(self.edit_frame, width=30)
            
            entry.grid(row=row, column=column+1, padx=5, pady=3, sticky="w")
            self.entries[col] = entry
        
        # 綁定數量和單價變更事件來自動計算總金額
        self.entries["數量"].bind("<KeyRelease>", self.update_total)
        self.entries["單價"].bind("<KeyRelease>", self.update_total)
        
        # 必填提示
        required_label = ttk.Label(self.edit_frame, text="* 為必填欄位", foreground="red", font=("Arial", 8))
        required_label.grid(row=len(self.columns)//2 + 1, column=0, columnspan=4, pady=5)
    
    def update_total(self, event=None):
        """自動計算總金額"""
        try:
            quantity = self.entries["數量"].get()
            unit_price = self.entries["單價"].get()
            
            if quantity and unit_price:
                total = float(quantity) * float(unit_price)
                self.entries["總金額"].config(state="normal")
                self.entries["總金額"].delete(0, tk.END)
                self.entries["總金額"].insert(0, f"{total:.2f}")
                self.entries["總金額"].config(state="readonly")
        except ValueError:
            # 如果輸入不是數字，清空總金額
            self.entries["總金額"].config(state="normal")
            self.entries["總金額"].delete(0, tk.END)
            self.entries["總金額"].config(state="readonly")
    
    def on_select(self, event):
        """當選中項目時，載入資料到編輯區"""
        selected = self.tree.selection()
        if selected:
            item = self.tree.item(selected[0])
            values = item['values']
            self.load_data_to_form(values)
            self.current_editing_item = selected[0]
    
    def load_data_to_form(self, values):
        """載入資料到表單"""
        for i, col in enumerate(self.columns):
            entry = self.entries[col]
            
            if col == "總金額":
                entry.config(state="normal")
                entry.delete(0, tk.END)
                entry.insert(0, str(values[i]))
                entry.config(state="readonly")
            elif hasattr(entry, 'set'):  # Combobox
                entry.set(str(values[i]))
            else:  # Entry
                entry.delete(0, tk.END)
                entry.insert(0, str(values[i]))
    
    def get_form_data(self):
        """從表單獲取資料"""
        data = []
        for col in self.columns:
            entry = self.entries[col]
            value = entry.get().strip()
            data.append(value)
        return data
    
    def validate_form_data(self, data):
        """驗證表單資料"""
        for i, col in enumerate(self.columns):
            # 必填欄位檢查
            if col in self.required_fields and not data[i]:
                messagebox.showerror("錯誤", f"{col} 為必填欄位")
                return False
            
            # 數字欄位檢查
            if col in ["數量", "單價", "總金額"] and data[i]:
                try:
                    float(data[i])
                except ValueError:
                    messagebox.showerror("錯誤", f"{col} 必須是數字")
                    return False
            
            # 日期格式檢查（簡單檢查）
            if col == "訂單日期" and data[i]:
                try:
                    datetime.strptime(data[i], "%Y-%m-%d")
                except ValueError:
                    messagebox.showerror("錯誤", "訂單日期格式應為 YYYY-MM-DD")
                    return False
        
        return True
    
    def clear_form(self):
        """清空表單"""
        for col in self.columns:
            entry = self.entries[col]
            
            if col == "總金額":
                entry.config(state="normal")
                entry.delete(0, tk.END)
                entry.config(state="readonly")
            elif col == "狀態":
                entry.set("待處理")
            elif col == "訂單日期":
                entry.delete(0, tk.END)
                entry.insert(0, datetime.now().strftime("%Y-%m-%d"))
            elif hasattr(entry, 'set'):  # Combobox
                entry.set("")
            else:  # Entry
                entry.delete(0, tk.END)
        
        self.current_editing_item = None
    
    def update_row_colors(self):
        """修正：更新行顏色（根據狀態和偶數列規則）"""
        for i, item in enumerate(self.tree.get_children()):
            values = self.tree.item(item)['values']
            if len(values) > 7:  # 確保有狀態欄位
                status = values[7]  # 狀態是第8個欄位（索引7）
                
                # 修正：優先判斷狀態顏色
                if status == "已完成":
                    self.tree.item(item, tags=("completed",))
                elif status == "已取消":
                    self.tree.item(item, tags=("cancelled",))
                else:
                    # 修正：偶數列（從1開始計算）用粉藍色
                    if (i + 1) % 2 == 0:  # 偶數列
                        self.tree.item(item, tags=("even",))
                    else:  # 奇數列
                        self.tree.item(item, tags=("odd",))
            else:
                # 如果沒有狀態欄位，使用一般的偶數/奇數行規則
                if (i + 1) % 2 == 0:  # 偶數列
                    self.tree.item(item, tags=("even",))
                else:
                    self.tree.item(item, tags=("odd",))
    
    def add_row(self):
        """新增資料"""
        data = self.get_form_data()
        
        if not self.validate_form_data(data):
            return
        
        # 檢查訂單編號是否重複
        for existing_data in self.data:
            if existing_data[0] == data[0]:
                messagebox.showerror("錯誤", "訂單編號已存在")
                return
        
        # 重新計算總金額確保正確
        if data[3] and data[4]:  # 數量和單價都有值
            try:
                total = float(data[3]) * float(data[4])
                data[5] = f"{total:.2f}"
            except ValueError:
                pass
        
        # 新增到資料和樹狀檢視
        self.data.append(data)
        self.tree.insert("", "end", values=data)
        
        # 更新行顏色
        self.update_row_colors()
        
        # 清空表單
        self.clear_form()
        
        # 儲存資料
        self.main_app.save_data()
        
        messagebox.showinfo("成功", "訂單已新增")
    
    def update_row(self):
        """修改資料"""
        if not self.current_editing_item:
            messagebox.showwarning("警告", "請先選擇要修改的訂單")
            return
        
        data = self.get_form_data()
        
        if not self.validate_form_data(data):
            return
        
        # 獲取原始資料
        old_values = self.tree.item(self.current_editing_item)['values']
        
        # 如果訂單編號改變，檢查是否重複
        if data[0] != old_values[0]:
            for existing_data in self.data:
                if existing_data[0] == data[0]:
                    messagebox.showerror("錯誤", "訂單編號已存在")
                    return
        
        # 重新計算總金額確保正確
        if data[3] and data[4]:  # 數量和單價都有值
            try:
                total = float(data[3]) * float(data[4])
                data[5] = f"{total:.2f}"
            except ValueError:
                pass
        
        # 更新資料
        if list(old_values) in self.data:
            index = self.data.index(list(old_values))
            self.data[index] = data
        
        # 更新樹狀檢視
        self.tree.item(self.current_editing_item, values=data)
        
        # 更新行顏色
        self.update_row_colors()
        
        # 清空表單
        self.clear_form()
        
        # 儲存資料
        self.main_app.save_data()
        
        messagebox.showinfo("成功", "訂單已修改")
    
    def delete_row(self):
        """刪除選中的資料"""
        selected = self.tree.selection()
        if not selected:
            messagebox.showwarning("警告", "請先選擇要刪除的訂單")
            return
        
        if messagebox.askyesno("確認", "確定要刪除選中的訂單嗎？"):
            for item in selected:
                # 從data中移除
                values = self.tree.item(item)['values']
                if list(values) in self.data:
                    self.data.remove(list(values))
                # 從tree中移除
                self.tree.delete(item)
            
            # 更新行顏色
            self.update_row_colors()
            
            # 清空表單
            self.clear_form()
            
            # 儲存資料
            self.main_app.save_data()
    
    def copy_row(self):
        """複製選中的資料"""
        selected = self.tree.selection()
        if not selected:
            messagebox.showwarning("警告", "請先選擇要複製的訂單")
            return
        
        item = self.tree.item(selected[0])
        values = list(item['values'])
        
        # 修改編號避免重複
        original_id = values[0]
        counter = 1
        while True:
            new_id = f"{original_id}_copy{counter}"
            # 檢查是否重複
            exists = False
            for existing_data in self.data:
                if existing_data[0] == new_id:
                    exists = True
                    break
            if not exists:
                values[0] = new_id
                break
            counter += 1
        
        # 更新日期為今天
        values[6] = datetime.now().strftime("%Y-%m-%d")
        
        # 新增資料
        self.data.append(values)
        self.tree.insert("", "end", values=values)
        
        # 更新行顏色
        self.update_row_colors()
        
        # 儲存資料
        self.main_app.save_data()
    
    def clear_all_data(self):
        """清除所有資料"""
        if messagebox.askyesno("確認", "確定要清除所有訂單資料嗎？"):
            self.data.clear()
            for item in self.tree.get_children():
                self.tree.delete(item)
            self.clear_form()
            self.main_app.save_data()
    
    def load_sample_data(self):
        """載入範例資料"""
        if not self.data:  # 只有在沒有資料時才載入範例
            sample_data = [
                ["O001", "台北科技公司", "筆記型電腦", "2", "25000", "50000", "2024-01-15", "已完成"],
                ["O002", "高雄貿易商行", "無線滑鼠\n藍牙連接", "10", "800", "8000", "2024-01-16", "處理中"],
                ["O003", "台中製造廠", "辦公椅", "5", "3500", "17500", "2024-01-17", "已取消"],
                ["O004", "新竹科技園區", "鍵盤組合\n機械軸", "3", "1200", "3600", "2024-01-18", "待處理"],
            ]
            self.load_data_from_list(sample_data)
    
    def load_data_from_list(self, data_list):
        """從清單載入資料"""
        # 清空現有資料
        self.data.clear()
        for item in self.tree.get_children():
            self.tree.delete(item)
        
        # 載入新資料
        for item in data_list:
            self.data.append(item)
            self.tree.insert("", "end", values=item)
        
        # 更新行顏色
        self.update_row_colors()
    
    def export_to_excel(self):
        """匯出到Excel"""
        if not self.data:
            messagebox.showwarning("警告", "沒有資料可以匯出")
            return
        
        try:
            # 創建工作簿
            wb = Workbook()
            ws = wb.active
            ws.title = "訂單管理"
            
            # 設置標題行
            for col_num, column_title in enumerate(self.columns, 1):
                cell = ws.cell(row=1, column=col_num)
                cell.value = column_title
                # 前5欄藍底白字，其他橘底黑字
                if col_num <= 5:
                    cell.fill = PatternFill(start_color="366092", end_color="366092", fill_type="solid")
                    cell.font = Font(color="FFFFFF", bold=True)
                else:
                    cell.fill = PatternFill(start_color="FFA500", end_color="FFA500", fill_type="solid")
                    cell.font = Font(color="000000", bold=True)
                cell.alignment = Alignment(horizontal="center", vertical="center")
            
            # 填入資料
            for row_num, row_data in enumerate(self.data, 2):
                for col_num, cell_value in enumerate(row_data, 1):
                    cell = ws.cell(row=row_num, column=col_num)
                    cell.value = cell_value
                    
                    # 第7欄（訂單日期）設為黃色背景
                    if col_num == 7:
                        cell.fill = PatternFill(start_color="FFFF00", end_color="FFFF00", fill_type="solid")
                    
                    # 數字欄位右對齊
                    if col_num in [4, 5, 6]:  # 數量、單價、總金額
                        cell.alignment = Alignment(horizontal="right", vertical="center", wrap_text=True)
                    else:
                        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
            
            # 凍結第一列和第一欄
            ws.freeze_panes = "B2"
            
            # 調整欄寬和行高
            column_widths = [12, 18, 20, 8, 12, 12, 15, 12]
            for i, width in enumerate(column_widths, 1):
                column_letter = get_column_letter(i)
                ws.column_dimensions[column_letter].width = width
            
            # 設置行高以支援多行文字
            for row in ws.iter_rows(min_row=2):
                ws.row_dimensions[row[0].row].height = 40
            
            # 選擇儲存位置
            filename = filedialog.asksaveasfilename(
                defaultextension=".xlsx",
                filetypes=[("Excel files", "*.xlsx"), ("All files", "*.*")],
                title="儲存訂單管理Excel檔案"
            )
            
            if filename:
                wb.save(filename)
                messagebox.showinfo("成功", f"已成功匯出到：{filename}")
        
        except Exception as e:
            messagebox.showerror("錯誤", f"匯出Excel時發生錯誤：{str(e)}")