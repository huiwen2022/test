import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from tksheet import Sheet
import os
import sys
sys.path.append(os.path.join(os.path.dirname(__file__), "libs"))
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment
from openpyxl.utils import get_column_letter
from datetime import datetime

class OrdersTab:
    def __init__(self, parent, main_app):
        self.parent = parent
        self.main_app = main_app
        self.data = []
        self.columns = ["訂單編號", "客戶名稱", "產品名稱", "數量", "單價", "總金額", "訂單日期", "狀態"]
        self.setup_ui()
        self.current_row = None

    def setup_ui(self):
        self.frame = ttk.Frame(self.parent)
        self.frame.pack(fill=tk.BOTH, expand=True)

        self.paned_window = ttk.PanedWindow(self.frame, orient=tk.VERTICAL)
        self.paned_window.pack(fill=tk.BOTH, expand=True)

        self.setup_data_display()
        self.setup_edit_area()

    def setup_data_display(self):
        self.top_frame = ttk.Frame(self.paned_window)
        self.paned_window.add(self.top_frame, weight=3)

        toolbar = ttk.Frame(self.top_frame)
        toolbar.pack(fill=tk.X, padx=5, pady=5)
        ttk.Button(toolbar, text="刪除選中", command=self.delete_row).pack(side=tk.LEFT, padx=2)
        ttk.Button(toolbar, text="複製選中", command=self.copy_row).pack(side=tk.LEFT, padx=2)
        ttk.Button(toolbar, text="清除全部", command=self.clear_all_data).pack(side=tk.LEFT, padx=2)
        ttk.Separator(toolbar, orient="vertical").pack(side=tk.LEFT, padx=10, fill=tk.Y)
        ttk.Button(toolbar, text="匯出Excel", command=self.export_to_excel).pack(side=tk.LEFT, padx=2)

        self.sheet_frame = ttk.Frame(self.top_frame)
        self.sheet_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

        self.sheet = Sheet(
            self.sheet_frame,
            headers=self.columns,
            data=self.data,
            table_wrap="w",
            header_wrap="w",
            column_width=120
        )
        self.sheet.enable_bindings("single_select", "row_select", "drag_select", "select_all")
        # 當使用者選取列/儲存格時，將資料載入下方表單
        getattr(self.sheet, "extra_bindings", lambda *a, **k: None)([("cell_select", self._on_sheet_select), ("row_select", self._on_sheet_select)])
        # 退而求其次：一般點擊後也試圖載入
        self.sheet.bind("<ButtonRelease-1>", self._on_sheet_select)
        self.sheet.grid(row=0, column=0, sticky="nsew")
        self.sheet_frame.grid_rowconfigure(0, weight=1)
        self.sheet_frame.grid_columnconfigure(0, weight=1)

        # 固定欄寬
        fixed_widths = [12,18,20,10,12,14,14,12]
        self.sheet.set_column_widths({i:w*7 for i,w in enumerate(fixed_widths)})

        self.apply_sheet_styles()

    def _bind_mousewheel(self, widget):
        # Windows / MacOS
        widget.bind_all("<MouseWheel>", lambda e: widget.yview_scroll(int(-1*(e.delta/120)), "units"))
        # Linux
        widget.bind_all("<Button-4>", lambda e: widget.yview_scroll(-1, "units"))
        widget.bind_all("<Button-5>", lambda e: widget.yview_scroll(1, "units"))

    def _setup_scrollable_edit_area(self, parent):
        # Canvas + Frame for scrollable edit area
        container = ttk.Frame(parent)
        container.pack(fill=tk.BOTH, expand=True)

        canvas = tk.Canvas(container, highlightthickness=0)
        vbar = ttk.Scrollbar(container, orient="vertical", command=canvas.yview)
        canvas.configure(yscrollcommand=vbar.set)

        inner = ttk.Frame(canvas)
        inner.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0,0), window=inner, anchor="nw")

        canvas.pack(side="left", fill="both", expand=True)
        vbar.pack(side="right", fill="y")

        # mouse wheel
        self._bind_mousewheel(canvas)
        return inner

    def _load_row_to_form(self, row_index):
        if row_index is None or not (0 <= row_index < len(self.data)):
            return
        values = self.data[row_index]
        for e, v in zip(self.inputs, values):
            e.delete(0, tk.END); e.insert(0, str(v))

    def _on_sheet_select(self, event=None):
        sel = getattr(self.sheet, "get_currently_selected", lambda: None)()
        r = getattr(sel, "row", None) if sel else None
        if r is None:
            return
        self._load_row_to_form(r)

    def setup_edit_area(self):
        self.bottom_frame = ttk.Frame(self.paned_window)
        self.paned_window.add(self.bottom_frame, weight=2)

        form = ttk.Frame(self.bottom_frame)
        form.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        labels = self.columns
        self.inputs = []
        for i, label in enumerate(labels):
            row = ttk.Frame(form)
            row.pack(fill=tk.X, pady=3)
            ttk.Label(row, text=label, width=10).pack(side=tk.LEFT)
            ent = ttk.Entry(row)
            ent.pack(side=tk.LEFT, fill=tk.X, expand=True)
            self.inputs.append(ent)

        btns = ttk.Frame(self.bottom_frame)
        btns.pack(pady=5)
        ttk.Button(btns, text="新增訂單", command=self.add_row).pack(side=tk.LEFT, padx=5)
        ttk.Button(btns, text="修改訂單", command=self.update_row).pack(side=tk.LEFT, padx=5)
        ttk.Button(btns, text="清空表單", command=self.clear_form).pack(side=tk.LEFT, padx=5)

    def get_selected_row(self):
        cur = self.sheet.get_currently_selected()
        if cur and hasattr(cur, "row") and cur.row is not None:
            return cur.row
        return None

    def add_row(self):
        values = [e.get() for e in self.inputs]
        if not any(values):
            messagebox.showwarning("警告", "請輸入資料")
            return
        # 計算總金額（若可）
        try:
            qty = float(values[3]); price = float(values[4])
            values[5] = qty * price
        except Exception:
            pass
        self.data.append(values)
        self.refresh_sheet()
        self.clear_form()

    def update_row(self):
        r = self.get_selected_row()
        if r is None or not (0 <= r < len(self.data)):
            messagebox.showwarning("警告", "請先選取要修改的列")
            return
        values = [e.get() for e in self.inputs]
        try:
            qty = float(values[3]); price = float(values[4])
            values[5] = qty * price
        except Exception:
            pass
        self.data[r] = values
        self.refresh_sheet()
        # 重載後維持當前選取列的表單資料
        if hasattr(self, 'current_row') and self.current_row is not None:
            self._load_row_to_form(self.current_row)

    def copy_row(self):
        r = self.get_selected_row()
        if r is None or not (0 <= r < len(self.data)):
            messagebox.showwarning("警告", "請先選取要複製的列")
            return
        self.data.append(self.data[r][:])
        self.refresh_sheet()

    def delete_row(self):
        r = self.get_selected_row()
        if r is None:
            messagebox.showwarning("警告", "請先選取要刪除的列")
            return
        if 0 <= r < len(self.data):
            del self.data[r]
            self.refresh_sheet()

    def clear_all_data(self):
        if messagebox.askyesno("確認", "確定清除全部資料？"):
            self.data.clear()
            self.refresh_sheet()

    def clear_form(self):
        for e in self.inputs:
            e.delete(0, tk.END)

    def set_data(self, rows):
        self.data = rows or []
        self.refresh_sheet()

    def get_data(self):
        return self.data

    def refresh_sheet(self):
        self.sheet.set_sheet_data(self.data, reset_highlights=True)
        self.apply_sheet_styles()
        self.sheet.redraw()

    def apply_sheet_styles(self):
        self.sheet.dehighlight_all()
        rows = len(self.data)
        cols = len(self.columns)
        # 偶數列粉藍
        even_rows = [r for r in range(rows) if (r+1)%2==0]
        if even_rows:
            self.sheet.highlight_rows(even_rows, bg="#E6F2FF")
        # 標題：前五藍底白字、其他橘底黑字
        first5 = list(range(min(5, cols)))
        others = list(range(5, cols))
        if first5:
            self.sheet.highlight_columns(first5, bg="#366092", fg="#FFFFFF", highlight_header=True)
        if others:
            self.sheet.highlight_columns(others, bg="#FFA500", fg="#000000", highlight_header=True)
        # 狀態規則
        status_idx = 7  # 第8欄
        for r, row in enumerate(self.data):
            st = str(row[status_idx]).strip() if len(row) > status_idx else ""
            if st == "已完成":
                self.sheet.highlight_cells(row=r, column=status_idx, bg="#D5F5E3")
            elif st == "已取消":
                self.sheet.highlight_rows([r], bg="#EEEEEE")

        # 對齊：數量、單價、總金額靠右
        for c in [3,4,5]:
            self.sheet.align_columns([c], align="e")

    # Excel 匯出
    def export_to_excel(self):
        if not self.data:
            messagebox.showwarning("警告", "沒有資料可以匯出")
            return
        filename = filedialog.asksaveasfilename(defaultextension=".xlsx", filetypes=[("Excel", "*.xlsx")])
        if not filename:
            return
        wb = Workbook()
        ws = wb.active
        ws.title = "訂單管理"
        BLUE = PatternFill(start_color="366092", end_color="366092", fill_type="solid")
        ORANGE = PatternFill(start_color="FFA500", end_color="FFA500", fill_type="solid")
        EVEN = PatternFill(start_color="E6F2FF", end_color="E6F2FF", fill_type="solid")
        GREEN = PatternFill(start_color="D5F5E3", end_color="D5F5E3", fill_type="solid")
        GRAY  = PatternFill(start_color="EEEEEE", end_color="EEEEEE", fill_type="solid")
        # 標題
        for i, t in enumerate(self.columns, 1):
            cell = ws.cell(row=1, column=i, value=t)
            if i <= 5:
                cell.fill = BLUE; cell.font = Font(color="FFFFFF", bold=True)
            else:
                cell.fill = ORANGE; cell.font = Font(color="000000", bold=True)
            cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        # 資料
        for r, row in enumerate(self.data, start=2):
            # 偶數列底色（先套）
            row_even = (r % 2 == 0)
            for c, v in enumerate(row, start=1):
                cell = ws.cell(row=r, column=c, value=v)
                if c in [4,5,6]:
                    cell.alignment = Alignment(horizontal="right", vertical="center", wrap_text=True)
                else:
                    cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
                if row_even:
                    cell.fill = EVEN
            # 狀態規則
            st = str(ws.cell(row=r, column=8).value or "").strip()
            if st == "已完成":
                ws.cell(row=r, column=8).fill = GREEN
            elif st == "已取消":
                for c in range(1, len(self.columns)+1):
                    ws.cell(row=r, column=c).fill = GRAY
        # 固定欄寬
        widths = [12,18,20,10,12,14,14,12]
        from openpyxl.utils import get_column_letter
        for i,w in enumerate(widths, start=1):
            ws.column_dimensions[get_column_letter(i)].width = w
        ws.freeze_panes = "B2"
        wb.save(filename)
        messagebox.showinfo("成功", f"已匯出：{os.path.basename(filename)}")

    def load_data_from_list(self, rows):
        """與舊版相容：從 list 載入資料"""
        self.set_data(rows or [])

    def load_sample_data(self):
        """與舊版相容：載入範例資料（僅在無資料時）"""
        if not self.data:
            sample_data = [
            [
                        "O001",
                        "台北科技公司",
                        "筆記型電腦",
                        "2",
                        "25000",
                        "50000",
                        "2024-01-15",
                        "已完成"
            ],
            [
                        "O002",
                        "高雄貿易商行",
                        "無線滑鼠",
                        "10",
                        "800",
                        "8000",
                        "2024-01-16",
                        "處理中"
            ],
            [
                        "O003",
                        "台中製造廠",
                        "辦公椅",
                        "5",
                        "3500",
                        "17500",
                        "2024-01-17",
                        "待出貨"
            ]
]
            self.set_data(sample_data)

